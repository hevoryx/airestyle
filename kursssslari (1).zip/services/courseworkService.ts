import type {
  CourseChapter,
  CourseIntro,
  CourseOutline,
  CourseProgress,
  CourseSettings,
  CourseWork,
  Language,
} from '../types';

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

const WORDS_PER_PAGE = 270; // A4, Times New Roman 14 pt, 1.5 line spacing
const FRONT_BACK_PAGES = 4; // title page, contents, references, spare
const INTRO_WORDS = 380;
const CONCLUSION_WORDS = 330;
const MAX_SECTION_WORDS = 1000;
const CONCURRENCY = 3;

const isPlainObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

export const countWords = (text: string): number =>
  text.trim() ? text.trim().split(/\s+/).length : 0;

/**
 * Normalises Uzbek Latin orthography:
 *  o' / g' (any apostrophe-like char)  ->  oʻ / gʻ  (U+02BB)
 *  other apostrophes inside a word     ->  ʼ (U+02BC, tutuq belgisi)
 */
export const normalizeUzbek = (text: string): string =>
  text
    .replace(/([oOgG])['‘’`´ʼʻ]/g, '$1ʻ')
    .replace(/(\p{L})['‘’`´](?=\p{L})/gu, '$1ʼ');

const normalizeFor = (language: Language, text: string): string => {
  const cleaned = text
    .replace(/\u00A0/g, ' ')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
  return language === 'uz' ? normalizeUzbek(cleaned) : cleaned;
};

export const normalizeCourseWork = (work: CourseWork): CourseWork => {
  const n = (text: string) => normalizeFor(work.language, text);
  const list = (items: string[]) => items.map(n).filter(Boolean);
  return {
    ...work,
    topic: n(work.topic),
    intro: {
      relevance: n(work.intro.relevance),
      goal: n(work.intro.goal),
      tasks: list(work.intro.tasks),
      object: n(work.intro.object),
      subject: n(work.intro.subject),
      methods: n(work.intro.methods),
      structure: n(work.intro.structure),
    },
    chapters: work.chapters.map((chapter) => ({
      title: n(chapter.title),
      sections: chapter.sections.map((section) => ({
        title: n(section.title),
        keyPoints: section.keyPoints,
        paragraphs: list(section.paragraphs),
      })),
    })),
    conclusion: list(work.conclusion),
    references: list(work.references),
  };
};

export const countCourseWorkWords = (work: CourseWork): number => {
  const i = work.intro;
  const parts = [
    i.relevance,
    i.goal,
    ...i.tasks,
    i.object,
    i.subject,
    i.methods,
    i.structure,
    ...work.chapters.flatMap((c) => c.sections.flatMap((s) => s.paragraphs)),
    ...work.conclusion,
  ];
  return parts.reduce((sum, p) => sum + countWords(p), 0);
};

export const estimatePages = (work: CourseWork): number =>
  Math.max(1, Math.round(countCourseWorkWords(work) / WORDS_PER_PAGE) + FRONT_BACK_PAGES);

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/* ------------------------------------------------------------------ */
/* API                                                                  */
/* ------------------------------------------------------------------ */

const postJson = async (url: string, body: unknown, signal?: AbortSignal): Promise<Record<string, unknown>> => {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });

  const text = await response.text();
  let payload: unknown = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = null;
  }

  if (!response.ok) {
    const message =
      isPlainObject(payload) && typeof payload.error === 'string'
        ? payload.error
        : `Request failed (HTTP ${response.status}).`;
    const err = new Error(message) as Error & { status?: number };
    err.status = response.status;
    throw err;
  }
  if (!isPlainObject(payload)) {
    throw new Error(`Unexpected server response (HTTP ${response.status}).`);
  }
  return payload;
};

const withClientRetry = async <T>(fn: () => Promise<T>, signal?: AbortSignal, attempts = 3): Promise<T> => {
  let lastError: unknown;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (signal?.aborted) throw err;
      const status = (err as { status?: number })?.status ?? 0;
      const missingKey = status === 503 && /api key/i.test(String((err as Error).message));
      const fatal = status === 400 || status === 401 || status === 403 || missingKey;
      if (fatal || attempt === attempts) throw err;
      await sleep(1200 * attempt);
    }
  }
  throw lastError;
};

const toOutlinePayload = (outline: CourseOutline) => ({
  title: outline.title,
  chapters: outline.chapters.map((c) => ({
    title: c.title,
    sections: c.sections.map((s) => ({ title: s.title, keyPoints: s.keyPoints })),
  })),
});

const parseOutline = (raw: unknown): CourseOutline => {
  if (!isPlainObject(raw) || !isPlainObject(raw.outline)) {
    throw new Error('Invalid course structure received from the server.');
  }
  const o = raw.outline as Record<string, unknown>;
  const chapters = Array.isArray(o.chapters) ? o.chapters : [];
  return {
    title: typeof o.title === 'string' ? o.title : '',
    chapters: chapters.map((c) => {
      const ch = c as Record<string, unknown>;
      const sections = Array.isArray(ch.sections) ? ch.sections : [];
      return {
        title: String(ch.title ?? ''),
        sections: sections.map((s) => {
          const sec = s as Record<string, unknown>;
          return {
            title: String(sec.title ?? ''),
            keyPoints: Array.isArray(sec.keyPoints) ? sec.keyPoints.map(String) : [],
          };
        }),
      };
    }),
  };
};

const outlineFromWork = (work: CourseWork): CourseOutline => ({
  title: work.topic,
  chapters: work.chapters.map((c) => ({
    title: c.title,
    sections: c.sections.map((s) => ({ title: s.title, keyPoints: s.keyPoints })),
  })),
});

interface PartContext {
  topic: string;
  subject: string;
  language: Language;
  outline: CourseOutline;
  additionalInfo?: string;
}

const requestSection = async (
  ctx: PartContext,
  ci: number,
  si: number,
  targetWords: number,
  signal?: AbortSignal
): Promise<string[]> => {
  const base = {
    kind: 'section',
    topic: ctx.topic,
    subject: ctx.subject,
    language: ctx.language,
    outline: toOutlinePayload(ctx.outline),
    chapterIndex: ci,
    sectionIndex: si,
    additionalInfo: ctx.additionalInfo,
  };

  const first = await withClientRetry(
    () => postJson('/api/coursework/part', { ...base, targetWords }, signal),
    signal
  );
  let paragraphs = Array.isArray(first.paragraphs) ? first.paragraphs.map(String) : [];

  // If the model wrote clearly less than requested, ask for additional paragraphs once.
  const written = paragraphs.reduce((sum, p) => sum + countWords(p), 0);
  if (written < targetWords * 0.72) {
    try {
      const more = await withClientRetry(
        () =>
          postJson(
            '/api/coursework/part',
            { ...base, targetWords: Math.min(MAX_SECTION_WORDS, targetWords - written), existing: paragraphs },
            signal
          ),
        signal,
        2
      );
      if (Array.isArray(more.paragraphs)) {
        paragraphs = [...paragraphs, ...more.paragraphs.map(String)];
      }
    } catch (err) {
      if (signal?.aborted) throw err;
      // keep what we have
    }
  }
  return paragraphs.map((p) => normalizeFor(ctx.language, p)).filter(Boolean);
};

/* ------------------------------------------------------------------ */
/* Public API                                                           */
/* ------------------------------------------------------------------ */

export const computeSectionWords = (pages: number, sectionCount: number): number => {
  const bodyPages = Math.max(8, pages - FRONT_BACK_PAGES);
  const bodyWords = bodyPages * WORDS_PER_PAGE;
  const perSection = (bodyWords - INTRO_WORDS - CONCLUSION_WORDS) / Math.max(1, sectionCount);
  return Math.min(MAX_SECTION_WORDS, Math.max(250, Math.round(perSection / 10) * 10));
};

export const generateCourseWork = async (
  settings: CourseSettings,
  onProgress: (p: CourseProgress) => void,
  signal?: AbortSignal
): Promise<CourseWork> => {
  const { topic, pages, chapterCount, language, additionalInfo, meta } = settings;

  onProgress({ done: 0, total: 1, label: 'outline' });
  const outlineRaw = await withClientRetry(
    () =>
      postJson(
        '/api/coursework/outline',
        { topic, pages, chapterCount, language, additionalInfo },
        signal
      ),
    signal
  );
  const outline = parseOutline(outlineRaw);
  const title = normalizeFor(language, outline.title || topic);
  outline.title = title;

  const sectionJobs: { ci: number; si: number }[] = [];
  outline.chapters.forEach((chapter, ci) =>
    chapter.sections.forEach((_s, si) => sectionJobs.push({ ci, si }))
  );

  const total = 1 + 3 + sectionJobs.length;
  let done = 1;
  const report = (label: string) => onProgress({ done, total, label });
  report('sections');

  const ctx: PartContext = {
    topic: title,
    subject: meta.subjectName,
    language,
    outline,
    additionalInfo,
  };
  const targetWords = computeSectionWords(pages, sectionJobs.length);

  const sectionText: string[][][] = outline.chapters.map((c) => c.sections.map(() => []));
  let intro: CourseIntro | null = null;
  let conclusion: string[] = [];
  let references: string[] = [];
  const failures: string[] = [];

  type Job = () => Promise<void>;
  const jobs: Job[] = [];

  jobs.push(async () => {
    try {
      const data = await withClientRetry(
        () =>
          postJson(
            '/api/coursework/part',
            {
              kind: 'intro',
              topic: title,
              subject: meta.subjectName,
              language,
              outline: toOutlinePayload(outline),
              additionalInfo,
            },
            signal
          ),
        signal
      );
      if (isPlainObject(data.intro)) {
        const i = data.intro as Record<string, unknown>;
        intro = {
          relevance: String(i.relevance ?? ''),
          goal: String(i.goal ?? ''),
          tasks: Array.isArray(i.tasks) ? i.tasks.map(String) : [],
          object: String(i.object ?? ''),
          subject: String(i.subject ?? ''),
          methods: String(i.methods ?? ''),
          structure: String(i.structure ?? ''),
        };
      }
    } catch (err) {
      if (signal?.aborted) throw err;
      failures.push('intro');
    }
    done += 1;
    report('intro');
  });

  for (const { ci, si } of sectionJobs) {
    jobs.push(async () => {
      try {
        sectionText[ci][si] = await requestSection(ctx, ci, si, targetWords, signal);
      } catch (err) {
        if (signal?.aborted) throw err;
        failures.push(`${ci + 1}.${si + 1}`);
      }
      done += 1;
      report('sections');
    });
  }

  jobs.push(async () => {
    try {
      const data = await withClientRetry(
        () =>
          postJson(
            '/api/coursework/part',
            {
              kind: 'conclusion',
              topic: title,
              subject: meta.subjectName,
              language,
              outline: toOutlinePayload(outline),
              targetWords: CONCLUSION_WORDS,
              additionalInfo,
            },
            signal
          ),
        signal
      );
      conclusion = Array.isArray(data.paragraphs) ? data.paragraphs.map(String) : [];
    } catch (err) {
      if (signal?.aborted) throw err;
      failures.push('conclusion');
    }
    done += 1;
    report('conclusion');
  });

  jobs.push(async () => {
    try {
      const data = await withClientRetry(
        () =>
          postJson(
            '/api/coursework/part',
            {
              kind: 'references',
              topic: title,
              subject: meta.subjectName,
              language,
              outline: toOutlinePayload(outline),
            },
            signal
          ),
        signal
      );
      references = Array.isArray(data.items) ? data.items.map(String) : [];
    } catch (err) {
      if (signal?.aborted) throw err;
      failures.push('references');
    }
    done += 1;
    report('references');
  });

  // Small worker pool
  let cursor = 0;
  const worker = async () => {
    while (cursor < jobs.length) {
      const job = jobs[cursor++];
      await job();
    }
  };
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, jobs.length) }, worker));

  // If everything failed, surface a clear error instead of an empty document.
  const anySectionText = sectionText.some((c) => c.some((s) => s.length > 0));
  if (!anySectionText && !intro) {
    throw new Error(
      language === 'uz'
        ? "Matn yaratib bo'lmadi. Internetni va API kalitni tekshirib, qayta urinib ko'ring."
        : language === 'ru'
          ? 'Не удалось создать текст. Проверьте интернет и API-ключ и попробуйте снова.'
          : 'Could not generate the text. Check your connection and API key, then try again.'
    );
  }

  const chapters: CourseChapter[] = outline.chapters.map((chapter, ci) => ({
    title: chapter.title,
    sections: chapter.sections.map((section, si) => ({
      title: section.title,
      keyPoints: section.keyPoints,
      paragraphs: sectionText[ci][si],
    })),
  }));

  return normalizeCourseWork({
    topic: title,
    language,
    pages,
    meta,
    intro: intro ?? {
      relevance: '',
      goal: '',
      tasks: [],
      object: '',
      subject: '',
      methods: '',
      structure: '',
    },
    chapters,
    conclusion,
    references,
  });
};

export const regenerateCourseSection = async (
  work: CourseWork,
  ci: number,
  si: number
): Promise<string[]> => {
  const sectionCount = work.chapters.reduce((sum, c) => sum + c.sections.length, 0);
  const ctx: PartContext = {
    topic: work.topic,
    subject: work.meta.subjectName,
    language: work.language,
    outline: outlineFromWork(work),
  };
  return requestSection(ctx, ci, si, computeSectionWords(work.pages, sectionCount));
};

export const regenerateCoursePart = async (
  work: CourseWork,
  kind: 'intro' | 'conclusion' | 'references'
): Promise<Partial<Pick<CourseWork, 'intro' | 'conclusion' | 'references'>>> => {
  const data = await withClientRetry(() =>
    postJson('/api/coursework/part', {
      kind,
      topic: work.topic,
      subject: work.meta.subjectName,
      language: work.language,
      outline: toOutlinePayload(outlineFromWork(work)),
      targetWords: CONCLUSION_WORDS,
    })
  );

  if (kind === 'intro' && isPlainObject(data.intro)) {
    const i = data.intro as Record<string, unknown>;
    return {
      intro: {
        relevance: String(i.relevance ?? ''),
        goal: String(i.goal ?? ''),
        tasks: Array.isArray(i.tasks) ? i.tasks.map(String) : [],
        object: String(i.object ?? ''),
        subject: String(i.subject ?? ''),
        methods: String(i.methods ?? ''),
        structure: String(i.structure ?? ''),
      },
    };
  }
  if (kind === 'conclusion') {
    return { conclusion: Array.isArray(data.paragraphs) ? data.paragraphs.map(String) : [] };
  }
  if (kind === 'references') {
    return { references: Array.isArray(data.items) ? data.items.map(String) : [] };
  }
  throw new Error('Unexpected server response.');
};
