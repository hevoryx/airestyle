import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { registerAiRoutes } from './src/server/aiRoutes.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  registerAiRoutes(app);

  app.all('/api/{*splat}', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use(
    (
      err: unknown,
      req: express.Request,
      res: express.Response,
      next: express.NextFunction
    ) => {
      if (res.headersSent) {
        next(err);
        return;
      }
      const maybeErr = err as { status?: number; statusCode?: number; type?: string };
      const status = maybeErr?.status ?? maybeErr?.statusCode;
      if (status === 413 || maybeErr?.type === 'entity.too.large') {
        res.status(413).json({
          error: 'Request payload exceeds the 12 MB limit. Please reduce file size.',
        });
        return;
      }
      if (maybeErr?.type === 'entity.parse.failed' || err instanceof SyntaxError) {
        res.status(400).json({ error: 'Invalid JSON request body.' });
        return;
      }
      if (req.path.startsWith('/api/')) {
        res.status(status && status >= 400 && status < 600 ? status : 500).json({
          error: 'Unexpected server error while processing API request.',
        });
        return;
      }
      next(err);
    }
  );

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI University Assistant server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
