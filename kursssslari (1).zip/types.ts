export type Language = 'uz' | 'ru' | 'en' | 'kaa' | 'kk';

export interface LanguageOption {
  code: Language;
  label: string;
  nativeName: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'uz', label: 'UZ', nativeName: "Oʻzbekcha" },
  { code: 'ru', label: 'RU', nativeName: 'Русский' },
  { code: 'en', label: 'EN', nativeName: 'English' },
  { code: 'kaa', label: 'KAA', nativeName: 'Qaraqalpaqsha' },
  { code: 'kk', label: 'KK', nativeName: 'Қазақша' },
];

export type ModuleId =
  | 'dashboard'
  | 'assistant'
  | 'documents'
  | 'presentations'
  | 'solver'
  | 'analyzer'
  | 'exams'
  | 'translator'
  | 'research'
  | 'planner'
  | 'workspace'
  | 'tools'
  | 'profile'
  | 'admin';

export type UserRole = 'student' | 'researcher' | 'instructor' | 'admin';
export type SubscriptionPlan = 'free' | 'pro' | 'university';
export type AcademicLevel = 'undergraduate' | 'masters' | 'phd' | 'researcher' | 'faculty';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoUrl?: string;
  role: UserRole;
  plan: SubscriptionPlan;
  preferredLanguage: Language;
  university?: string;
  faculty?: string;
  academicLevel?: AcademicLevel;
  aiRequestsUsed: number;
  aiMonthlyLimit: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PlatformConfig {
  activeModel: string;
  announcement: string;
  announcementActive: boolean;
  defaultMonthlyLimit: number;
  disabledTools: string[];
  enabledLanguages: string[];
  updatedAt?: unknown;
}

export interface SystemLog {
  id: string;
  userId: string;
  userEmail?: string;
  tool: string;
  model: string;
  status: 'ok' | 'error';
  tokens: number;
  errorMessage?: string;
  createdAt?: unknown;
}

/* ------------------------------------------------------------------ */
/* Workspace & File Management                                        */
/* ------------------------------------------------------------------ */

export type WorkspaceType =
  | 'document'
  | 'presentation'
  | 'math'
  | 'research'
  | 'analysis'
  | 'exam'
  | 'note'
  | 'resume';

export interface WorkspaceItem {
  id: string;
  userId: string;
  title: string;
  type: WorkspaceType;
  docSubtype?: string;
  folder: string;
  language: Language;
  summary?: string;
  content: Record<string, unknown>;
  versionCount: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface WorkspaceVersion {
  id: string;
  userId: string;
  versionNumber: number;
  note?: string;
  content: Record<string, unknown>;
  createdAt?: unknown;
}

/* ------------------------------------------------------------------ */
/* Tasks & Academic Planner                                           */
/* ------------------------------------------------------------------ */

export type TaskKind = 'assignment' | 'exam' | 'study' | 'deadline';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'todo' | 'in_progress' | 'completed';

export interface AcademicTask {
  id: string;
  userId: string;
  title: string;
  subject?: string;
  kind: TaskKind;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  dueTime?: string;
  notes?: string;
  reminder: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

/* ------------------------------------------------------------------ */
/* Core AI Assistant                                                  */
/* ------------------------------------------------------------------ */

export interface ChatAttachment {
  name: string;
  mimeType: string;
  textExcerpt?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  mode?: 'simple' | 'advanced';
  recommendedTool?: ModuleId;
  attachments?: ChatAttachment[];
  sources?: { title: string; uri: string }[];
  createdAt: string;
}

export interface AssistantChat {
  id: string;
  userId: string;
  title: string;
  language: Language;
  rememberContext: boolean;
  messages: ChatMessage[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

/* ------------------------------------------------------------------ */
/* Academic Document Generator (17 Document Types)                    */
/* ------------------------------------------------------------------ */

export type AcademicDocType =
  | 'kurs_ishi'
  | 'diplom_ishi'
  | 'magistr_dissertatsiya'
  | 'referat'
  | 'mustaqil_ish'
  | 'amaliy_ish'
  | 'laboratoriya_ishi'
  | 'esse'
  | 'ilmiy_maqola'
  | 'hisobot'
  | 'taqdimot_matni'
  | 'maruza_matni'
  | 'seminar_materiallari'
  | 'konspekt'
  | 'biznes_loyiha'
  | 'case_study'
  | 'research_proposal';

export type CitationStandard = 'uz_dst' | 'apa' | 'mla' | 'chicago' | 'ieee' | 'gost';

export interface AcademicSection {
  id: string;
  title: string;
  paragraphs: string[];
  examples?: string;
}

export interface AcademicChapter {
  id: string;
  title: string;
  sections: AcademicSection[];
}

export interface AcademicReference {
  citation: string;
  url?: string;
  verified: boolean;
}

export interface GeneratedAcademicDocument {
  id?: string;
  docType: AcademicDocType;
  topic: string;
  subject: string;
  academicLevel: AcademicLevel;
  language: Language;
  targetPages: number;
  standard: CitationStandard;
  universityMeta: {
    ministry: string;
    university: string;
    faculty: string;
    student: string;
    group: string;
    supervisor: string;
    city: string;
    year: string;
  };
  introduction: string[];
  chapters: AcademicChapter[];
  conclusion: string[];
  references: AcademicReference[];
  complianceNote: string;
}

/* ------------------------------------------------------------------ */
/* Presentations (Existing + Enhanced Styles, Charts, Tables)         */
/* ------------------------------------------------------------------ */

export type LayoutType =
  | 'title'
  | 'split_left'
  | 'split_right'
  | 'minimal_typography'
  | 'timeline_flow'
  | 'comparison_grid'
  | 'editorial_spotlight';

export type VisualKind =
  | 'stat'
  | 'steps'
  | 'highlights'
  | 'quote'
  | 'timeline'
  | 'comparison'
  | 'chart'
  | 'table';

export type VisualMotif =
  | 'orbital'
  | 'waves'
  | 'nodes'
  | 'peaks'
  | 'grid'
  | 'prism';

export interface SlideVisualItem {
  label: string;
  value: string;
  numericValue?: number;
}

export interface SlideVisual {
  kind: VisualKind;
  heading: string;
  items: SlideVisualItem[];
  tableHeaders?: string[];
  tableRows?: string[][];
}

export type PresentationStyle =
  | 'minimalist'
  | 'academic'
  | 'corporate'
  | 'modern'
  | 'dark'
  | 'light'
  | 'scientific';

export interface Theme {
  id: string;
  name: string;
  style?: PresentationStyle;
  isDark?: boolean;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
    textLight: string;
  };
  font: string;
}

export interface Slide {
  title: string;
  sectionTag?: string;
  content: string[];
  layout: LayoutType;
  visual?: SlideVisual;
  visualMotif?: VisualMotif;
  speakerNotes?: string;
  imageData?: string;
}

export interface UsageStats {
  model: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

export interface PresentationPlanResponse {
  themeId: string;
  slides: Slide[];
  usageStats: UsageStats;
}

export enum AppStatus {
  IDLE = 'IDLE',
  GENERATING_PLAN = 'GENERATING_PLAN',
  READY = 'READY',
  ERROR = 'ERROR',
}

/* ------------------------------------------------------------------ */
/* Coursework Legacy Compatibility (preserved for existing utils)     */
/* ------------------------------------------------------------------ */

export interface CourseMeta {
  ministry: string;
  university: string;
  faculty: string;
  subjectName: string;
  student: string;
  group: string;
  supervisor: string;
  city: string;
  year: string;
}

export interface CourseSettings {
  topic: string;
  pages: number;
  chapterCount: number;
  language: Language;
  additionalInfo?: string;
  meta: CourseMeta;
}

export interface CourseSection {
  title: string;
  keyPoints: string[];
  paragraphs: string[];
}

export interface CourseChapter {
  title: string;
  sections: CourseSection[];
}

export interface CourseIntro {
  relevance: string;
  goal: string;
  tasks: string[];
  object: string;
  subject: string;
  methods: string;
  structure: string;
}

export interface CourseWork {
  topic: string;
  language: Language;
  pages: number;
  meta: CourseMeta;
  intro: CourseIntro;
  chapters: CourseChapter[];
  conclusion: string[];
  references: string[];
}

export interface CourseOutline {
  title: string;
  chapters: {
    title: string;
    sections: { title: string; keyPoints: string[] }[];
  }[];
}

export interface CourseProgress {
  done: number;
  total: number;
  label: string;
}

/* ------------------------------------------------------------------ */
/* Math & Economics Solver                                            */
/* ------------------------------------------------------------------ */

export type SolverSubject =
  | 'mathematics'
  | 'statistics'
  | 'microeconomics'
  | 'macroeconomics'
  | 'econometrics'
  | 'accounting'
  | 'finance'
  | 'business_math'
  | 'probability'
  | 'linear_algebra'
  | 'calculus';

export interface MathSolutionStep {
  stepNumber: number;
  title: string;
  explanation: string;
  formulaLatex: string;
  intermediateResult: string;
}

export interface MathSolution {
  subject: SolverSubject;
  extractedExpression: string;
  steps: MathSolutionStep[];
  independentVerification: {
    verified: boolean;
    method: string;
    auditNote: string;
    detectedErrors: string[];
  };
  finalAnswer: string;
  finalAnswerLatex: string;
  tableData?: {
    headers: string[];
    rows: string[][];
  };
  graphPoints?: {
    xLabel: string;
    yLabel: string;
    seriesName: string;
    points: { x: number; y: number; label?: string }[];
  };
  uncertaintyNote?: string;
}

/* ------------------------------------------------------------------ */
/* Document Analyzer                                                  */
/* ------------------------------------------------------------------ */

export interface AnalyzedDocument {
  fileName: string;
  fileType: string;
  extractedTextPreview: string;
  structure: { heading: string; summary: string }[];
  executiveSummary: string;
  keyFindings: string[];
  studyNotes: string[];
  extractedQA: { question: string; answer: string; sourceLocation: string }[];
  quizPreview: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }[];
  sourceBoundaryNotice: string;
}

/* ------------------------------------------------------------------ */
/* Test & Exam System                                                 */
/* ------------------------------------------------------------------ */

export type ExamQuestionType = 'mcq' | 'true_false' | 'open';
export type ExamMode = 'practice' | 'learning';

export interface ExamQuestion {
  id: string;
  type: ExamQuestionType;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  topicTag: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  hint?: string;
}

export interface ExamBundle {
  topic: string;
  subject: string;
  questions: ExamQuestion[];
  flashcards: Flashcard[];
  prepPlan: { day: string; focus: string; tasks: string[] }[];
}

export interface StudyProgress {
  id: string;
  userId: string;
  topic: string;
  subject?: string;
  mode: 'practice' | 'learning' | 'flashcards';
  score: number;
  totalQuestions: number;
  percentage: number;
  weakAreas?: string[];
  createdAt?: unknown;
}

/* ------------------------------------------------------------------ */
/* Research Workspace                                                 */
/* ------------------------------------------------------------------ */

export interface ResearchBundle {
  topic: string;
  researchQuestions: string[];
  hypotheses: string[];
  literatureSynthesis: string;
  studyComparisons: {
    studyTitle: string;
    methodology: string;
    keyFindings: string;
    limitations: string;
  }[];
  unsupportedClaimsAudit: string[];
  verifiedSources: {
    title: string;
    url: string;
    snippet?: string;
    citations: {
      apa: string;
      mla: string;
      chicago: string;
      ieee: string;
    };
  }[];
  suggestedDirections: string[];
  integrityNotice: string;
}
