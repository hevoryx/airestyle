import React, { useMemo, useState } from 'react';
import {
  Bell,
  Calendar as CalendarIcon,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Edit3,
  ListTodo,
  Plus,
  Trash2,
} from 'lucide-react';
import type { AcademicTask, TaskKind, TaskPriority, TaskStatus } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { createTask, deleteTask, updateTask } from '../lib/firestoreService';

interface PlannerViewProps {
  tasks: AcademicTask[];
}

const toIsoDate = (date: Date): string => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const getWeekDays = (anchor: Date): Date[] => {
  const start = new Date(anchor);
  const day = start.getDay();
  const diff = day === 0 ? -6 : 1 - day; // Monday start
  start.setDate(start.getDate() + diff);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
};

const getMonthGrid = (anchor: Date): { date: Date; inMonth: boolean }[] => {
  const year = anchor.getFullYear();
  const month = anchor.getMonth();
  const firstDay = new Date(year, month, 1);
  const firstDow = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1;
  const start = new Date(year, month, 1 - firstDow);

  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return { date: d, inMonth: d.getMonth() === month };
  });
};

export const PlannerView: React.FC<PlannerViewProps> = ({ tasks }) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [viewMode, setViewMode] = useState<'list' | 'week' | 'month'>('list');
  const [filterKind, setFilterKind] = useState<'all' | TaskKind>('all');
  const [filterStatus, setFilterStatus] = useState<'active' | 'completed' | 'all'>('active');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [anchorDate, setAnchorDate] = useState<Date>(() => new Date());

  // Form state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [kind, setKind] = useState<TaskKind>('assignment');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [dueDate, setDueDate] = useState(() => toIsoDate(new Date()));
  const [dueTime, setDueTime] = useState('14:00');
  const [notes, setNotes] = useState('');
  const [reminder, setReminder] = useState(true);
  const [saving, setSaving] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const resetForm = (targetDate?: string) => {
    setEditingId(null);
    setTitle('');
    setSubject('');
    setKind('assignment');
    setPriority('medium');
    setDueDate(targetDate || toIsoDate(new Date()));
    setDueTime('14:00');
    setNotes('');
    setReminder(true);
  };

  const handleEditTask = (task: AcademicTask) => {
    setEditingId(task.id);
    setTitle(task.title);
    setSubject(task.subject || '');
    setKind(task.kind);
    setPriority(task.priority);
    setDueDate(task.dueDate || toIsoDate(new Date()));
    setDueTime(task.dueTime || '');
    setNotes(task.notes || '');
    setReminder(task.reminder);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setSaving(true);
    setError(null);
    try {
      if (editingId) {
        await updateTask(editingId, {
          title: title.trim(),
          subject: subject.trim(),
          kind,
          priority,
          dueDate,
          dueTime,
          notes: notes.trim(),
          reminder,
        });
      } else {
        await createTask(firebaseUser.uid, {
          title: title.trim(),
          subject: subject.trim(),
          kind,
          priority,
          status: 'todo',
          dueDate,
          dueTime,
          notes: notes.trim(),
          reminder,
        });
      }
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save task.');
    } finally {
      setSaving(false);
    }
  };

  const toggleStatus = async (task: AcademicTask) => {
    const nextStatus: TaskStatus =
      task.status === 'completed' ? 'todo' : task.status === 'todo' ? 'in_progress' : 'completed';
    try {
      await updateTask(task.id, { status: nextStatus });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status.');
    }
  };

  const handleMarkDone = async (task: AcademicTask) => {
    const nextStatus: TaskStatus = task.status === 'completed' ? 'todo' : 'completed';
    try {
      await updateTask(task.id, { status: nextStatus });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update task.');
    }
  };

  const handleDelete = async (taskId: string) => {
    try {
      await deleteTask(taskId);
      setConfirmDeleteId(null);
      if (editingId === taskId) resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete task.');
    }
  };

  const uniqueSubjects = useMemo(() => {
    const set = new Set<string>();
    tasks.forEach((tk) => {
      if (tk.subject?.trim()) set.add(tk.subject.trim());
    });
    return Array.from(set).sort();
  }, [tasks]);

  const priorityRank: Record<TaskPriority, number> = { urgent: 0, high: 1, medium: 2, low: 3 };

  const filteredTasks = useMemo(() => {
    return tasks
      .filter((tk) => {
        if (filterKind !== 'all' && tk.kind !== filterKind) return false;
        if (filterStatus === 'active' && tk.status === 'completed') return false;
        if (filterStatus === 'completed' && tk.status !== 'completed') return false;
        if (subjectFilter && (tk.subject || '').trim() !== subjectFilter) return false;
        return true;
      })
      .sort((a, b) => {
        if (a.status === 'completed' && b.status !== 'completed') return 1;
        if (a.status !== 'completed' && b.status === 'completed') return -1;
        const pDiff = priorityRank[a.priority] - priorityRank[b.priority];
        if (a.dueDate !== b.dueDate) return a.dueDate.localeCompare(b.dueDate);
        return pDiff;
      });
  }, [tasks, filterKind, filterStatus, subjectFilter]);

  const stats = useMemo(() => {
    const active = tasks.filter((x) => x.status !== 'completed');
    const urgent = active.filter((x) => x.priority === 'urgent' || x.priority === 'high');
    const exams = active.filter((x) => x.kind === 'exam');
    const done = tasks.filter((x) => x.status === 'completed');
    return { active: active.length, urgent: urgent.length, exams: exams.length, done: done.length };
  }, [tasks]);

  const weekDays = useMemo(() => getWeekDays(anchorDate), [anchorDate]);
  const monthGrid = useMemo(() => getMonthGrid(anchorDate), [anchorDate]);
  const todayIso = toIsoDate(new Date());

  const shiftPeriod = (dir: -1 | 1) => {
    const next = new Date(anchorDate);
    if (viewMode === 'week') {
      next.setDate(next.getDate() + dir * 7);
    } else {
      next.setMonth(next.getMonth() + dir);
    }
    setAnchorDate(next);
  };

  const priorityTone: Record<TaskPriority, string> = {
    urgent: 'text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border-red-200 dark:border-red-900',
    high: 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-900',
    medium: 'text-sky-700 dark:text-sky-300 bg-sky-50 dark:bg-sky-950/50 border-sky-200 dark:border-sky-900',
    low: 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700',
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* KPI Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Active Tasks</p>
          <p className="mt-1 text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">{stats.active}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Urgent & High Priority</p>
          <p className="mt-1 text-2xl font-bold text-red-600 dark:text-red-400 tabular-nums">{stats.urgent}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Upcoming Exams</p>
          <p className="mt-1 text-2xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">{stats.exams}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Completed</p>
          <p className="mt-1 text-2xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">{stats.done}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Task Editor Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {editingId ? t.common.edit : 'Add Assignment / Exam'}
            </h2>
            {editingId && (
              <button
                type="button"
                onClick={() => resetForm()}
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
              >
                {t.common.cancel}
              </button>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
              Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Econometrics Midterm Prep"
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g., Statistics"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Category
              </label>
              <select
                value={kind}
                onChange={(e) => setKind(e.target.value as TaskKind)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none"
              >
                <option value="assignment">Assignment</option>
                <option value="exam">Exam Date</option>
                <option value="study">Study Block</option>
                <option value="deadline">Deadline</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Due Date
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Time
              </label>
              <input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
              Priority
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['low', 'medium', 'high', 'urgent'] as TaskPriority[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`py-1.5 text-xs font-medium rounded-lg border capitalize cursor-pointer ${
                    priority === p
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
              Notes / Syllabus Chapters
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Chapters, room number, submission requirements..."
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none resize-none"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={reminder}
              onChange={(e) => setReminder(e.target.checked)}
              className="rounded border-slate-300 dark:border-slate-700"
            />
            <Bell className="w-3.5 h-3.5 text-slate-500" />
            Mark reminder active for this deadline
          </label>

          {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}

          <button
            type="submit"
            disabled={saving || !title.trim()}
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold disabled:opacity-50 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            {saving ? t.common.saving : editingId ? t.common.save : 'Add to Planner'}
          </button>
        </form>

        {/* Main Calendar & Task Workspace */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
          {/* Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer whitespace-nowrap shrink-0 ${
                  viewMode === 'list'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <ListTodo className="w-3.5 h-3.5" />
                List
              </button>
              <button
                type="button"
                onClick={() => setViewMode('week')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer whitespace-nowrap shrink-0 ${
                  viewMode === 'week'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                Weekly
              </button>
              <button
                type="button"
                onClick={() => setViewMode('month')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer whitespace-nowrap shrink-0 ${
                  viewMode === 'month'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <CalendarIcon className="w-3.5 h-3.5" />
                Monthly
              </button>
            </div>

            {viewMode === 'list' ? (
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as 'active' | 'completed' | 'all')}
                  className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
                >
                  <option value="active">Active</option>
                  <option value="completed">Completed</option>
                  <option value="all">All Statuses</option>
                </select>
                <select
                  value={filterKind}
                  onChange={(e) => setFilterKind(e.target.value as 'all' | TaskKind)}
                  className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
                >
                  <option value="all">All Types</option>
                  <option value="assignment">Assignments</option>
                  <option value="exam">Exams</option>
                  <option value="study">Study Schedules</option>
                  <option value="deadline">Deadlines</option>
                </select>
                {uniqueSubjects.length > 0 && (
                  <select
                    value={subjectFilter}
                    onChange={(e) => setSubjectFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
                  >
                    <option value="">All Subjects</option>
                    {uniqueSubjects.map((sub) => (
                      <option key={sub} value={sub}>
                        {sub}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => shiftPeriod(-1)}
                  className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 min-w-[130px] text-center">
                  {anchorDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}
                </span>
                <button
                  type="button"
                  onClick={() => shiftPeriod(1)}
                  className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setAnchorDate(new Date())}
                  className="px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Today
                </button>
              </div>
            )}
          </div>

          {/* LIST VIEW */}
          {viewMode === 'list' && (
            <div className="space-y-2.5">
              {filteredTasks.length === 0 ? (
                <div className="py-12 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  <CalendarIcon className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                  <p className="text-sm text-slate-500 dark:text-slate-400">{t.dashboard.noTasks}</p>
                </div>
              ) : (
                filteredTasks.map((task) => {
                  const overdue = task.status !== 'completed' && task.dueDate < todayIso;
                  return (
                    <div
                      key={task.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <button
                          type="button"
                          onClick={() => void handleMarkDone(task)}
                          title="Toggle complete"
                          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center shrink-0 cursor-pointer ${
                            task.status === 'completed'
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 dark:border-slate-600 hover:border-blue-500'
                          }`}
                        >
                          {task.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5" />}
                        </button>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <p
                              className={`text-sm font-semibold ${
                                task.status === 'completed'
                                  ? 'line-through text-slate-400'
                                  : 'text-slate-900 dark:text-slate-100'
                              }`}
                            >
                              {task.title}
                            </p>
                            <span className={`text-[11px] font-medium px-2 py-0.5 rounded border ${priorityTone[task.priority]}`}>
                              {task.priority}
                            </span>
                            {overdue && (
                              <span className="text-[11px] font-semibold text-red-600 dark:text-red-400">
                                Overdue
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {task.subject ? `${task.subject} · ` : ''}
                            {task.kind} · Due <span className="font-mono tabular-nums">{task.dueDate}</span>
                            {task.dueTime ? ` at ${task.dueTime}` : ''}
                            {task.reminder ? ' · Reminder on' : ''}
                          </p>
                          {task.notes && (
                            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{task.notes}</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => void toggleStatus(task)}
                          className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                        >
                          {task.status === 'todo'
                            ? 'Start'
                            : task.status === 'in_progress'
                            ? 'In Progress'
                            : 'Reopen'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleEditTask(task)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                          title={t.common.edit}
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        {confirmDeleteId === task.id ? (
                          <button
                            type="button"
                            onClick={() => void handleDelete(task.id)}
                            className="px-2 py-1 text-xs bg-red-600 text-white rounded-md cursor-pointer"
                          >
                            Confirm
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(task.id)}
                            className="p-1.5 text-slate-500 hover:text-red-600 cursor-pointer"
                            title={t.common.delete}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* WEEKLY CALENDAR VIEW */}
          {viewMode === 'week' && (
            <div className="grid grid-cols-1 sm:grid-cols-7 gap-2.5">
              {weekDays.map((day) => {
                const iso = toIsoDate(day);
                const dayTasks = tasks.filter((tk) => tk.dueDate === iso);
                const isToday = iso === todayIso;
                return (
                  <div
                    key={iso}
                    className={`min-h-[180px] rounded-xl border p-3 flex flex-col gap-2 ${
                      isToday
                        ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/20'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-950/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                          {day.toLocaleDateString(undefined, { weekday: 'short' })}
                        </p>
                        <p className="text-sm font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                          {day.getDate()}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => resetForm(iso)}
                        title="Schedule on this day"
                        className="p-1 text-slate-400 hover:text-blue-600 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="space-y-1.5">
                      {dayTasks.map((tk) => (
                        <button
                          key={tk.id}
                          type="button"
                          onClick={() => handleEditTask(tk)}
                          className={`w-full text-left p-2 rounded-lg border text-xs cursor-pointer ${
                            tk.status === 'completed'
                              ? 'opacity-55 line-through bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                              : priorityTone[tk.priority]
                          }`}
                        >
                          <p className="font-semibold truncate">{tk.title}</p>
                          {tk.dueTime && <p className="text-[10px] opacity-80 tabular-nums">{tk.dueTime}</p>}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* MONTHLY CALENDAR VIEW */}
          {viewMode === 'month' && (
            <div>
              <div className="grid grid-cols-7 gap-1 mb-1 text-center text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
                  <div key={d} className="py-1">
                    {d}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {monthGrid.map(({ date, inMonth }) => {
                  const iso = toIsoDate(date);
                  const dayTasks = tasks.filter((tk) => tk.dueDate === iso);
                  const isToday = iso === todayIso;
                  return (
                    <div
                      key={iso}
                      onClick={() => resetForm(iso)}
                      className={`min-h-[82px] p-1.5 rounded-lg border cursor-pointer transition-colors ${
                        isToday
                          ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/20'
                          : inMonth
                          ? 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                          : 'border-slate-100 dark:border-slate-900 bg-slate-50/40 dark:bg-slate-950/40 opacity-50'
                      }`}
                    >
                      <div className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 tabular-nums mb-1">
                        {date.getDate()}
                      </div>
                      <div className="space-y-0.5">
                        {dayTasks.slice(0, 2).map((tk) => (
                          <div
                            key={tk.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditTask(tk);
                            }}
                            className={`px-1.5 py-0.5 rounded text-[10px] truncate ${
                              tk.status === 'completed'
                                ? 'bg-slate-200 dark:bg-slate-800 text-slate-500 line-through'
                                : tk.kind === 'exam'
                                ? 'bg-blue-600 text-white'
                                : 'bg-slate-800 dark:bg-slate-700 text-white'
                            }`}
                          >
                            {tk.title}
                          </div>
                        ))}
                        {dayTasks.length > 2 && (
                          <div className="text-[10px] text-slate-500 px-1">+{dayTasks.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
