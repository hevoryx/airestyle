import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Download,
  Edit3,
  ImagePlus,
  Presentation,
  RefreshCw,
  Save,
} from 'lucide-react';
import type { PresentationStyle, Slide, Theme, WorkspaceItem } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { getTheme, THEMES } from '../../utils/themes';
import { generatePPTX } from '../../utils/pptxGenerator';
import { downloadPresentationPdf } from '../utils/exportGenerators';
import { saveWorkspaceItem } from '../lib/firestoreService';

const STYLE_OPTIONS: { id: PresentationStyle; label: string; themeId: string }[] = [
  { id: 'minimalist', label: 'Minimalist', themeId: 'minimalist_light' },
  { id: 'academic', label: 'Academic', themeId: 'academic_navy' },
  { id: 'corporate', label: 'Corporate', themeId: 'corporate_slate' },
  { id: 'modern', label: 'Modern', themeId: 'modern_blue' },
  { id: 'dark', label: 'Dark', themeId: 'minimal_dark' },
  { id: 'light', label: 'Light', themeId: 'nature_green' },
  { id: 'scientific', label: 'Scientific', themeId: 'scientific_cyan' },
];

interface PresentationsViewProps {
  loadedWorkspaceItem?: WorkspaceItem | null;
}

export const PresentationsView: React.FC<PresentationsViewProps> = ({ loadedWorkspaceItem }) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [topic, setTopic] = useState('');
  const [slideCount, setSlideCount] = useState(8);
  const [style, setStyle] = useState<PresentationStyle>('academic');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [slides, setSlides] = useState<Slide[]>([]);
  const [theme, setTheme] = useState<Theme>(THEMES.academic_navy);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [editing, setEditing] = useState(false);
  const [refineInstruction, setRefineInstruction] = useState('');
  const [loading, setLoading] = useState(false);
  const [refining, setRefining] = useState(false);
  const [savedId, setSavedId] = useState<string | undefined>(undefined);
  const [saveDone, setSaveDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loadedWorkspaceItem && loadedWorkspaceItem.type === 'presentation') {
      const content = loadedWorkspaceItem.content as {
        topic?: string;
        themeId?: string;
        slides?: Slide[];
      };
      if (Array.isArray(content?.slides)) {
        setTopic(content.topic || loadedWorkspaceItem.title);
        setTheme(getTheme(content.themeId));
        setSlides(content.slides);
        setCurrentIndex(0);
        setSavedId(loadedWorkspaceItem.id);
      }
    }
  }, [loadedWorkspaceItem]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    setLoading(true);
    setError(null);
    setSaveDone(false);
    setSavedId(undefined);

    try {
      const resp = await callAiApi<{ themeId: string; slides: Slide[] }>(
        '/api/presentation/plan',
        {
          topic: topic.trim(),
          slideCount,
          planCount: Math.max(2, Math.min(6, Math.floor(slideCount / 2))),
          language,
          style,
          additionalInfo: additionalInfo.trim(),
        },
        'presentations'
      );
      const chosenStyle = STYLE_OPTIONS.find((s) => s.id === style);
      setTheme(getTheme(chosenStyle?.themeId || resp.themeId));
      setSlides(resp.slides);
      setCurrentIndex(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate slides.');
    } finally {
      setLoading(false);
    }
  };

  const activeSlide = slides[currentIndex];

  const handleRefineSlide = async () => {
    if (!activeSlide || !refineInstruction.trim() || !firebaseUser) return;
    setRefining(true);
    setError(null);
    try {
      const resp = await callAiApi<{ slide: Slide }>(
        '/api/presentation/refine-slide',
        {
          topic,
          slide: activeSlide,
          instruction: refineInstruction.trim(),
          language,
        },
        'presentations_refine'
      );
      setSlides((prev) =>
        prev.map((s, idx) => (idx === currentIndex ? { ...resp.slide, imageData: s.imageData } : s))
      );
      setRefineInstruction('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Slide refinement failed.');
    } finally {
      setRefining(false);
    }
  };

  const handleSlideImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const img = reader.result;
        setSlides((prev) => prev.map((s, i) => (i === currentIndex ? { ...s, imageData: img } : s)));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!firebaseUser || slides.length === 0) return;
    try {
      const id = await saveWorkspaceItem({
        id: savedId,
        userId: firebaseUser.uid,
        title: topic || 'Presentation',
        type: 'presentation',
        docSubtype: style,
        folder: 'Presentations',
        language,
        summary: `${slides.length} slides · ${theme.name}`,
        content: { topic, themeId: theme.id, slides },
      });
      setSavedId(id);
      setSaveDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <form
        onSubmit={handleGenerate}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              {t.nav.presentations}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              7 design styles · Charts & tables · Speaker notes · PPTX & PDF export
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {STYLE_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  setStyle(opt.id);
                  setTheme(getTheme(opt.themeId));
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer whitespace-nowrap ${
                  style === opt.id
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <input
            type="text"
            required
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Presentation topic (e.g., Markaziy Osiyoda yashil energetika istiqbollari)"
            className="md:col-span-6 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
          <input
            type="number"
            min={3}
            max={25}
            value={slideCount}
            onChange={(e) => setSlideCount(Number(e.target.value))}
            className="md:col-span-2 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono"
            title="Slide count"
          />
          <input
            type="text"
            value={additionalInfo}
            onChange={(e) => setAdditionalInfo(e.target.value)}
            placeholder="Academic / business audience notes..."
            className="md:col-span-4 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
        </div>

        <div className="flex items-center justify-end gap-3">
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 cursor-pointer inline-flex items-center gap-2 whitespace-nowrap disabled:opacity-50"
          >
            <Presentation className="w-4 h-4" />
            {loading ? t.common.generating : t.common.generate}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </form>

      {slides.length > 0 && activeSlide && (
        <div className="space-y-4">
          {/* Toolbar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex((i) => Math.max(0, i - 1))}
                className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-40 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono font-semibold px-2 tabular-nums">
                {currentIndex + 1} / {slides.length}
              </span>
              <button
                type="button"
                disabled={currentIndex === slides.length - 1}
                onClick={() => setCurrentIndex((i) => Math.min(slides.length - 1, i + 1))}
                className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg disabled:opacity-40 cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <label className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium cursor-pointer inline-flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800">
                <ImagePlus className="w-3.5 h-3.5" />
                Attach Visual
                <input type="file" accept="image/*" onChange={handleSlideImageUpload} className="hidden" />
              </label>
              <button
                type="button"
                onClick={() => setEditing((v) => !v)}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium cursor-pointer inline-flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <Edit3 className="w-3.5 h-3.5" />
                {editing ? 'Preview' : t.common.edit}
              </button>
              <button
                type="button"
                onClick={() => void handleSave()}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium cursor-pointer inline-flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {saveDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Save className="w-3.5 h-3.5" />}
                {saveDone ? t.common.saved : t.common.save}
              </button>
              <button
                type="button"
                onClick={() => void generatePPTX(topic, slides, theme)}
                className="px-3.5 py-1.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold cursor-pointer inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                {t.common.downloadPptx}
              </button>
              <button
                type="button"
                onClick={() => downloadPresentationPdf(topic, slides, theme)}
                className="px-3.5 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold cursor-pointer inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                {t.common.downloadPdf}
              </button>
            </div>
          </div>

          {/* Slide Canvas */}
          <div
            className="rounded-xl border border-slate-200 dark:border-slate-800 p-8 md:p-12 min-h-[420px] flex flex-col justify-between"
            style={{ backgroundColor: theme.colors.background, color: theme.colors.text }}
          >
            {editing ? (
              <div className="space-y-4">
                <input
                  type="text"
                  value={activeSlide.title}
                  onChange={(e) =>
                    setSlides((prev) =>
                      prev.map((s, i) => (i === currentIndex ? { ...s, title: e.target.value } : s))
                    )
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-900 bg-white font-bold text-lg"
                />
                <textarea
                  rows={5}
                  value={activeSlide.content.join('\n')}
                  onChange={(e) =>
                    setSlides((prev) =>
                      prev.map((s, i) =>
                        i === currentIndex ? { ...s, content: e.target.value.split('\n') } : s
                      )
                    )
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-900 bg-white text-sm"
                />
                <textarea
                  rows={2}
                  value={activeSlide.speakerNotes || ''}
                  onChange={(e) =>
                    setSlides((prev) =>
                      prev.map((s, i) => (i === currentIndex ? { ...s, speakerNotes: e.target.value } : s))
                    )
                  }
                  placeholder="Speaker notes..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-900 bg-white text-xs"
                />
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-4">
                  {activeSlide.sectionTag && (
                    <p
                      className="text-xs font-semibold tracking-wider uppercase"
                      style={{ color: theme.colors.accent }}
                    >
                      {activeSlide.sectionTag}
                    </p>
                  )}
                  <h3
                    className="font-display text-2xl md:text-3xl font-bold leading-tight"
                    style={{ color: theme.colors.primary }}
                  >
                    {activeSlide.title}
                  </h3>
                  <ul className="space-y-2.5 text-sm md:text-base leading-relaxed">
                    {activeSlide.content.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span style={{ color: theme.colors.accent }}>•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="lg:col-span-5">
                  {activeSlide.imageData ? (
                    <img
                      src={activeSlide.imageData}
                      alt={activeSlide.title}
                      className="w-full h-64 object-cover rounded-xl border border-slate-300/40"
                    />
                  ) : activeSlide.visual?.kind === 'table' && activeSlide.visual.tableHeaders ? (
                    <div className="rounded-xl border border-slate-300/30 p-4 overflow-x-auto bg-black/5">
                      <p className="text-xs font-bold mb-2" style={{ color: theme.colors.accent }}>
                        {activeSlide.visual.heading}
                      </p>
                      <table className="w-full text-xs">
                        <thead>
                          <tr>
                            {activeSlide.visual.tableHeaders.map((h, hi) => (
                              <th key={hi} className="text-left pb-1.5 border-b border-current/20 pr-2">
                                {h}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {(activeSlide.visual.tableRows || []).map((row, ri) => (
                            <tr key={ri}>
                              {row.map((cell, ci) => (
                                <td key={ci} className="py-1 pr-2 border-b border-current/10">
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : activeSlide.visual?.kind === 'chart' && activeSlide.visual.items?.length ? (
                    <div className="rounded-xl border border-slate-300/30 p-4 space-y-2.5 bg-black/5">
                      <p className="text-xs font-bold" style={{ color: theme.colors.accent }}>
                        {activeSlide.visual.heading}
                      </p>
                      {activeSlide.visual.items.map((item, idx) => {
                        const maxVal = Math.max(
                          ...activeSlide.visual!.items.map((x) => x.numericValue || 100),
                          1
                        );
                        const pct = Math.min(100, Math.round(((item.numericValue || 60) / maxVal) * 100));
                        return (
                          <div key={idx} className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>{item.label}</span>
                              <span className="font-mono">{item.value}</span>
                            </div>
                            <div className="h-2 rounded-full bg-current/15 overflow-hidden">
                              <div
                                className="h-full rounded-full"
                                style={{ width: `${pct}%`, backgroundColor: theme.colors.accent }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : activeSlide.visual?.items?.length ? (
                    <div className="rounded-xl border border-slate-300/30 p-4 space-y-2.5 bg-black/5">
                      <p className="text-xs font-bold" style={{ color: theme.colors.accent }}>
                        {activeSlide.visual.heading}
                      </p>
                      {activeSlide.visual.items.slice(0, 4).map((item, idx) => (
                        <div key={idx} className="p-2.5 rounded-lg border border-current/15">
                          <p className="text-xs font-semibold" style={{ color: theme.colors.accent }}>
                            {item.label}
                          </p>
                          <p className="text-xs mt-0.5">{item.value}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <img
                      src="/src/assets/images/scientific_geometry_cover_1795370100202.jpg"
                      alt="Academic slide visual"
                      referrerPolicy="no-referrer"
                      className="w-full h-56 object-cover rounded-xl opacity-90"
                    />
                  )}
                </div>
              </div>
            )}

            {activeSlide.speakerNotes && !editing && (
              <div className="mt-6 pt-4 border-t border-current/15 text-xs opacity-80">
                <strong>Speaker notes:</strong> {activeSlide.speakerNotes}
              </div>
            )}
          </div>

          {/* AI Slide Refiner */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-wrap items-center gap-3">
            <input
              type="text"
              value={refineInstruction}
              onChange={(e) => setRefineInstruction(e.target.value)}
              placeholder="Refine this slide with AI (e.g., Add numerical comparison table or simplify bullet points)"
              className="flex-1 min-w-[240px] px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
            />
            <button
              type="button"
              disabled={refining || !refineInstruction.trim()}
              onClick={() => void handleRefineSlide()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refining ? 'animate-spin' : ''}`} />
              Refine Slide
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
