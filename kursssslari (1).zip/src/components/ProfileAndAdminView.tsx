import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  LogOut,
  Save,
  ShieldCheck,
  Users,
} from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  type AcademicLevel,
  type Language,
  type ModuleId,
  type SubscriptionPlan,
  type SystemLog,
  type UserProfile,
  type UserRole,
} from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import {
  adminUpdateUser,
  listAllUsersAdmin,
  listSystemLogs,
  savePlatformConfig,
  updateUserProfile,
} from '../lib/firestoreService';

export const ProfileView: React.FC = () => {
  const { firebaseUser, profile, isAdmin, language, setLanguage, logout, refreshProfile, signInWithGoogle } =
    useAuth();
  const t = UI_STRINGS[language];

  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [university, setUniversity] = useState(profile?.university || '');
  const [faculty, setFaculty] = useState(profile?.faculty || '');
  const [academicLevel, setAcademicLevel] = useState<AcademicLevel>(profile?.academicLevel || 'undergraduate');
  const [preferredLanguage, setPreferredLanguage] = useState<Language>(profile?.preferredLanguage || language);
  const [myLogs, setMyLogs] = useState<SystemLog[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || '');
      setUniversity(profile.university || '');
      setFaculty(profile.faculty || '');
      setAcademicLevel(profile.academicLevel || 'undergraduate');
      setPreferredLanguage(profile.preferredLanguage || language);
    }
  }, [profile, language]);

  useEffect(() => {
    if (firebaseUser) {
      listSystemLogs(firebaseUser.uid)
        .then(setMyLogs)
        .catch(() => setMyLogs([]));
    }
  }, [firebaseUser]);

  if (!firebaseUser || !profile) {
    return (
      <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
          {t.auth.signInRequiredTitle}
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400">{t.auth.signInRequiredDesc}</p>
        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 cursor-pointer"
        >
          {t.auth.signInGoogle}
        </button>
      </div>
    );
  }

  const usagePct = Math.min(100, Math.round((profile.aiRequestsUsed / Math.max(1, profile.aiMonthlyLimit)) * 100));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      await updateUserProfile(profile.uid, {
        displayName,
        university,
        faculty,
        academicLevel,
        preferredLanguage,
      });
      setLanguage(preferredLanguage);
      await refreshProfile();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Account Summary & Quota */}
      <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-3">
          {profile.photoUrl ? (
            <img src={profile.photoUrl} alt={profile.displayName} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
              {profile.displayName.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="min-w-0">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100 truncate">
              {profile.displayName}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{profile.email}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
            <p className="text-slate-500">Role</p>
            <p className="mt-1 font-semibold uppercase text-slate-900 dark:text-slate-100">
              {isAdmin ? 'Admin' : profile.role}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
            <p className="text-slate-500">Subscription Plan</p>
            <p className="mt-1 font-semibold uppercase text-blue-600 dark:text-blue-400">{profile.plan}</p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 dark:text-slate-400">Monthly AI Usage</span>
            <span className="font-mono font-semibold tabular-nums">
              {profile.aiRequestsUsed} / {profile.aiMonthlyLimit}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-blue-600 transition-all" style={{ width: `${usagePct}%` }} />
          </div>
        </div>

        <button
          type="button"
          onClick={() => void logout()}
          className="w-full inline-flex items-center justify-center gap-2 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          {t.auth.signOut}
        </button>
      </div>

      {/* Edit Profile + Personal Log */}
      <div className="lg:col-span-7 space-y-6">
        <form
          onSubmit={handleSave}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Academic Profile Settings
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Display Name</label>
              <input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Academic Level</label>
              <select
                value={academicLevel}
                onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="undergraduate">Undergraduate (Bakalavr)</option>
                <option value="masters">Master's (Magistratura)</option>
                <option value="phd">PhD / Doctoral</option>
                <option value="researcher">Researcher</option>
                <option value="faculty">Faculty / Instructor</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">University</label>
              <input
                value={university}
                onChange={(e) => setUniversity(e.target.value)}
                placeholder="e.g., National University of Uzbekistan"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Faculty / Department</label>
              <input
                value={faculty}
                onChange={(e) => setFaculty(e.target.value)}
                placeholder="e.g., Economics & Applied Mathematics"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs text-slate-500 mb-1">Preferred Language</label>
              <select
                value={preferredLanguage}
                onChange={(e) => setPreferredLanguage(e.target.value as Language)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.label})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {error && <p className="text-xs text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 cursor-pointer"
          >
            {saved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saving ? t.common.saving : saved ? t.common.saved : t.common.save}
          </button>
        </form>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Recent AI Activity
          </h3>
          {myLogs.length === 0 ? (
            <p className="text-xs text-slate-500">No AI requests recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-60 overflow-y-auto">
              {myLogs.slice(0, 12).map((log) => (
                <div key={log.id} className="py-2 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{log.tool}</span>
                    <span className="text-slate-400 ml-2 font-mono">{log.model}</span>
                  </div>
                  <div className="flex items-center gap-3 tabular-nums">
                    <span className="text-slate-500">{log.tokens} tok</span>
                    <span className={log.status === 'ok' ? 'text-emerald-600' : 'text-red-500'}>
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/* ================================================================== */
/* Admin Console                                                      */
/* ================================================================== */

const TOGGLEABLE_TOOLS: { id: ModuleId; label: string }[] = [
  { id: 'assistant', label: 'Core AI Assistant' },
  { id: 'documents', label: 'Academic Documents' },
  { id: 'presentations', label: 'Presentations' },
  { id: 'solver', label: 'Math & Economics Solver' },
  { id: 'analyzer', label: 'Document Analyzer' },
  { id: 'exams', label: 'Exam System' },
  { id: 'translator', label: 'Translator & Writing' },
  { id: 'research', label: 'Research Assistant' },
  { id: 'tools', label: 'Student Utilities' },
];

export const AdminView: React.FC = () => {
  const { firebaseUser, isAdmin, platformConfig } = useAuth();

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [userEdits, setUserEdits] = useState<
    Record<string, { role: UserRole; plan: SubscriptionPlan; aiMonthlyLimit: number }>
  >({});

  // Config draft state
  const [activeModel, setActiveModel] = useState(platformConfig.activeModel);
  const [defaultLimit, setDefaultLimit] = useState(platformConfig.defaultMonthlyLimit);
  const [announcement, setAnnouncement] = useState(platformConfig.announcement);
  const [announcementActive, setAnnouncementActive] = useState(platformConfig.announcementActive);
  const [disabledTools, setDisabledTools] = useState<string[]>(platformConfig.disabledTools);
  const [enabledLanguages, setEnabledLanguages] = useState<string[]>(platformConfig.enabledLanguages);
  const [showErrorsOnly, setShowErrorsOnly] = useState(false);
  const [savingConfig, setSavingConfig] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setActiveModel(platformConfig.activeModel);
    setDefaultLimit(platformConfig.defaultMonthlyLimit);
    setAnnouncement(platformConfig.announcement);
    setAnnouncementActive(platformConfig.announcementActive);
    setDisabledTools(platformConfig.disabledTools);
    setEnabledLanguages(platformConfig.enabledLanguages);
  }, [platformConfig]);

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    setLoading(true);
    Promise.all([listAllUsersAdmin(), listSystemLogs()])
      .then(([uList, lList]) => {
        setUsers(uList);
        setLogs(lList);
        const map: Record<string, { role: UserRole; plan: SubscriptionPlan; aiMonthlyLimit: number }> = {};
        uList.forEach((u) => {
          map[u.uid] = { role: u.role, plan: u.plan, aiMonthlyLimit: u.aiMonthlyLimit };
        });
        setUserEdits(map);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load admin data.'))
      .finally(() => setLoading(false));
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <div className="max-w-lg mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-3">
        <ShieldCheck className="w-9 h-9 text-red-500 mx-auto" />
        <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
          Administrator Access Required
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Only authorized platform administrators can view user management, model settings, and system logs.
        </p>
      </div>
    );
  }

  const handleSaveUser = async (target: UserProfile) => {
    if (!firebaseUser) return;
    const draft = userEdits[target.uid];
    if (!draft) return;
    setError(null);
    try {
      await adminUpdateUser(target.uid, target.email, firebaseUser.uid, draft);
      setStatusMsg(`Updated ${target.email}`);
      setTimeout(() => setStatusMsg(null), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user.');
    }
  };

  const handleSavePlatform = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    setError(null);
    try {
      await savePlatformConfig({
        activeModel,
        announcement,
        announcementActive,
        defaultMonthlyLimit: defaultLimit,
        disabledTools,
        enabledLanguages,
      });
      setStatusMsg('Platform configuration saved.');
      setTimeout(() => setStatusMsg(null), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save platform settings.');
    } finally {
      setSavingConfig(false);
    }
  };

  const toggleDisabledTool = (toolId: string) => {
    setDisabledTools((prev) => (prev.includes(toolId) ? prev.filter((x) => x !== toolId) : [...prev, toolId]));
  };

  const toggleEnabledLang = (code: string) => {
    setEnabledLanguages((prev) => {
      if (prev.includes(code)) {
        return prev.length > 1 ? prev.filter((x) => x !== code) : prev;
      }
      return [...prev, code];
    });
  };

  const totalTokens = logs.reduce((acc, l) => acc + (l.tokens || 0), 0);
  const errorLogs = logs.filter((l) => l.status === 'error');
  const visibleLogs = showErrorsOnly ? errorLogs : logs;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Analytics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> Registered Users</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{users.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><Activity className="w-3.5 h-3.5" /> Logged AI Requests</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{logs.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500">Total Tokens</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{totalTokens.toLocaleString()}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><AlertCircle className="w-3.5 h-3.5" /> System Errors</p>
          <p className="mt-1 text-2xl font-bold text-red-600 tabular-nums">{errorLogs.length}</p>
        </div>
      </div>

      {statusMsg && (
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-xl px-4 py-3 text-xs text-emerald-700 dark:text-emerald-300">
          {statusMsg}
        </div>
      )}
      {error && (
        <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {/* Platform Config */}
      <form
        onSubmit={handleSavePlatform}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            AI Models, Languages, Tools & Announcements
          </h2>
          <button
            type="submit"
            disabled={savingConfig}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            {savingConfig ? 'Saving...' : 'Save Configuration'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Active AI Model</label>
            <select
              value={activeModel}
              onChange={(e) => setActiveModel(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="gemini-4-hydrogen">gemini-4-hydrogen (Primary)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast Fallback)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Default Monthly Limit</label>
            <input
              type="number"
              min={1}
              value={defaultLimit}
              onChange={(e) => setDefaultLimit(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
            />
          </div>
          <div className="flex items-end pb-2">
            <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={announcementActive}
                onChange={(e) => setAnnouncementActive(e.target.checked)}
              />
              Show Platform Announcement Banner
            </label>
          </div>
        </div>

        <div>
          <label className="block text-xs text-slate-500 mb-1">Platform Announcement Text</label>
          <input
            value={announcement}
            onChange={(e) => setAnnouncement(e.target.value)}
            placeholder="System notice, exam season update, maintenance schedule..."
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">Enabled Languages</p>
            <div className="flex flex-wrap gap-2">
              {SUPPORTED_LANGUAGES.map((l) => {
                const enabled = enabledLanguages.includes(l.code);
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => toggleEnabledLang(l.code)}
                    className={`px-3 py-1.5 text-xs rounded-lg border cursor-pointer ${
                      enabled
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {l.nativeName}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
              Available Tools (Click to pause/enable)
            </p>
            <div className="flex flex-wrap gap-2">
              {TOGGLEABLE_TOOLS.map((tool) => {
                const disabled = disabledTools.includes(tool.id);
                return (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => toggleDisabledTool(tool.id)}
                    className={`px-2.5 py-1 text-xs rounded-lg border cursor-pointer ${
                      disabled
                        ? 'bg-red-50 dark:bg-red-950/40 text-red-600 border-red-300 dark:border-red-900 line-through'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {tool.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </form>

      {/* User & Subscription Management */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Users, Subscriptions & Quotas
        </h2>
        {loading ? (
          <p className="text-sm text-slate-500">Loading users...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-2 pr-3">User</th>
                  <th className="py-2 pr-3">Role</th>
                  <th className="py-2 pr-3">Plan</th>
                  <th className="py-2 pr-3">Usage / Limit</th>
                  <th className="py-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => {
                  const ed = userEdits[u.uid] || { role: u.role, plan: u.plan, aiMonthlyLimit: u.aiMonthlyLimit };
                  return (
                    <tr key={u.uid}>
                      <td className="py-2.5 pr-3">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{u.displayName}</p>
                        <p className="text-slate-500">{u.email}</p>
                      </td>
                      <td className="py-2.5 pr-3">
                        <select
                          value={ed.role}
                          onChange={(e) =>
                            setUserEdits({ ...userEdits, [u.uid]: { ...ed, role: e.target.value as UserRole } })
                          }
                          className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="student">student</option>
                          <option value="researcher">researcher</option>
                          <option value="instructor">instructor</option>
                          <option value="admin">admin</option>
                        </select>
                      </td>
                      <td className="py-2.5 pr-3">
                        <select
                          value={ed.plan}
                          onChange={(e) =>
                            setUserEdits({
                              ...userEdits,
                              [u.uid]: { ...ed, plan: e.target.value as SubscriptionPlan },
                            })
                          }
                          className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="free">free</option>
                          <option value="pro">pro</option>
                          <option value="university">university</option>
                        </select>
                      </td>
                      <td className="py-2.5 pr-3 tabular-nums">
                        <span>{u.aiRequestsUsed} / </span>
                        <input
                          type="number"
                          value={ed.aiMonthlyLimit}
                          onChange={(e) =>
                            setUserEdits({
                              ...userEdits,
                              [u.uid]: { ...ed, aiMonthlyLimit: Number(e.target.value) || 100 },
                            })
                          }
                          className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded tabular-nums"
                        />
                      </td>
                      <td className="py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => void handleSaveUser(u)}
                          className="px-3 py-1 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded font-medium cursor-pointer"
                        >
                          Save
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* System Logs & Errors */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            System Usage & Error Logs
          </h2>
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={showErrorsOnly} onChange={(e) => setShowErrorsOnly(e.target.checked)} />
            Errors Only ({errorLogs.length})
          </label>
        </div>

        <div className="overflow-x-auto max-h-80">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2 pr-3">User</th>
                <th className="py-2 pr-3">Tool</th>
                <th className="py-2 pr-3">Model</th>
                <th className="py-2 pr-3">Tokens</th>
                <th className="py-2">Status / Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {visibleLogs.map((l) => (
                <tr key={l.id}>
                  <td className="py-2 pr-3 text-slate-600 dark:text-slate-300">{l.userEmail || l.userId}</td>
                  <td className="py-2 pr-3 font-mono">{l.tool}</td>
                  <td className="py-2 pr-3 font-mono text-slate-500">{l.model}</td>
                  <td className="py-2 pr-3 tabular-nums">{l.tokens}</td>
                  <td className="py-2">
                    <span className={l.status === 'ok' ? 'text-emerald-600' : 'text-red-600 font-semibold'}>
                      {l.status}
                    </span>
                    {l.errorMessage && <span className="ml-2 text-red-500">{l.errorMessage}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
