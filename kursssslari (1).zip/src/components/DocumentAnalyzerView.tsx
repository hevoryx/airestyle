import React, { useState } from 'react';
import {
  CheckCircle2,
  FileSearch,
  HelpCircle,
  Save,
  UploadCloud,
} from 'lucide-react';
import type { AnalyzedDocument } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { parseUploadedFile, type ParsedUpload } from '../utils/fileParsers';
import { saveWorkspaceItem } from '../lib/firestoreService';

export const DocumentAnalyzerView: React.FC = () => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [parsedFile, setParsedFile] = useState<ParsedUpload | null>(null);
  const [analysis, setAnalysis] = useState<AnalyzedDocument | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'summary' | 'notes' | 'qa' | 'quiz'>('summary');
  const [loading, setLoading] = useState(false);
  const [asking, setAsking] = useState(false);
  const [saveDone, setSaveDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setAnalysis(null);
    setAnswer(null);
    setSaveDone(false);

    try {
      const parsed = await parseUploadedFile(file);
      setParsedFile(parsed);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse file.');
    }
  };

  const handleAnalyze = async () => {
    if (!parsedFile) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const resp = await callAiApi<{ analysis: AnalyzedDocument }>(
        '/api/analyzer/analyze',
        {
          fileName: parsedFile.fileName,
          mimeType: parsedFile.mimeType,
          extractedText: parsedFile.extractedText,
          base64Data: parsedFile.base64Data,
          language,
        },
        'analyzer'
      );
      setAnalysis(resp.analysis);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Document analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || !parsedFile) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    setAsking(true);
    setError(null);
    try {
      const resp = await callAiApi<{ answer: string }>(
        '/api/analyzer/ask',
        {
          question: question.trim(),
          documentContext: parsedFile.extractedText || analysis?.extractedTextPreview,
          base64Data: parsedFile.base64Data,
          mimeType: parsedFile.mimeType,
          language,
        },
        'analyzer_ask'
      );
      setAnswer(resp.answer);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not answer question.');
    } finally {
      setAsking(false);
    }
  };

  const handleSave = async () => {
    if (!analysis || !firebaseUser) return;
    await saveWorkspaceItem({
      userId: firebaseUser.uid,
      title: `Analysis: ${analysis.fileName}`,
      type: 'analysis',
      folder: 'Document Analyses',
      language,
      summary: analysis.executiveSummary.slice(0, 260),
      content: analysis as unknown as Record<string, unknown>,
    });
    setSaveDone(true);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            {t.nav.analyzer}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Upload PDF, DOCX, XLSX, PPTX, JPG, or PNG · OCR extraction · Study notes & quizzes · Strictly separates file facts from external context
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 p-4 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <UploadCloud className="w-6 h-6 text-slate-500" />
            <div>
              <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                {parsedFile ? parsedFile.fileName : 'Select a document or image (max 8 MB)'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {parsedFile
                  ? `${parsedFile.mimeType} · ${Math.round(parsedFile.sizeBytes / 1024)} KB`
                  : 'Supported: PDF, DOCX, XLSX, PPTX, JPG, PNG, TXT'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label className="px-4 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-lg text-xs font-semibold cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
              {t.common.uploadFile}
              <input
                type="file"
                accept=".pdf,.docx,.xlsx,.xls,.pptx,.txt,.md,.csv,.jpg,.jpeg,.png,.webp"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
            <button
              type="button"
              disabled={!parsedFile || loading}
              onClick={() => void handleAnalyze()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-1.5"
            >
              <FileSearch className="w-4 h-4" />
              {loading ? t.common.generating : 'Analyze Document'}
            </button>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </div>

      {analysis && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                {(
                  [
                    ['summary', 'Summary & Structure'],
                    ['notes', 'Study Notes'],
                    ['qa', 'Extracted Q&A'],
                    ['quiz', 'Quiz Preview'],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setActiveTab(id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer whitespace-nowrap ${
                      activeTab === id
                        ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => void handleSave()}
                className="px-3.5 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {saveDone ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4" />}
                {saveDone ? t.common.saved : t.common.save}
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-600 dark:text-slate-400">
              {analysis.sourceBoundaryNotice}
            </div>

            {activeTab === 'summary' && (
              <div className="space-y-5">
                <div>
                  <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 mb-2">
                    Executive Summary
                  </h3>
                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                    {analysis.executiveSummary}
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Key Findings
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                      {analysis.keyFindings.map((k, i) => (
                        <li key={i}>{k}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Detected Document Structure
                    </h4>
                    <div className="space-y-2">
                      {analysis.structure.map((s, i) => (
                        <div key={i} className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                          <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                            {s.heading}
                          </p>
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                            {s.summary}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notes' && (
              <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-disc pl-5">
                {analysis.studyNotes.map((note, idx) => (
                  <li key={idx} className="leading-relaxed">
                    {note}
                  </li>
                ))}
              </ul>
            )}

            {activeTab === 'qa' && (
              <div className="space-y-3">
                {analysis.extractedQA.map((item, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg space-y-1">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      Q: {item.question}
                    </p>
                    <p className="text-sm text-slate-700 dark:text-slate-300">A: {item.answer}</p>
                    <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                      Source: {item.sourceLocation}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'quiz' && (
              <div className="space-y-4">
                {analysis.quizPreview.map((q, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg space-y-2">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      {idx + 1}. {q.question}
                    </p>
                    <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300">
                      {q.options.map((opt, oi) => (
                        <li
                          key={oi}
                          className={
                            oi === q.correctIndex ? 'font-semibold text-emerald-700 dark:text-emerald-400' : ''
                          }
                        >
                          {String.fromCharCode(65 + oi)}. {opt}
                        </li>
                      ))}
                    </ul>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{q.explanation}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Ask Questions About Document */}
          <form
            onSubmit={handleAsk}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3"
          >
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <HelpCircle className="w-4 h-4" />
              Ask About This Document
            </h3>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask a specific question grounded in the uploaded file..."
                className="flex-1 min-w-[240px] px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
              />
              <button
                type="submit"
                disabled={asking || !question.trim()}
                className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold disabled:opacity-50 cursor-pointer"
              >
                {asking ? t.common.generating : 'Ask'}
              </button>
            </div>
            {answer && (
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                {answer}
              </div>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
