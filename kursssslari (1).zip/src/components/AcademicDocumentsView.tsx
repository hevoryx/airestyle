import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  RefreshCw,
  Save,
  ShieldCheck,
} from 'lucide-react';
import type {
  AcademicDocType,
  AcademicLevel,
  CitationStandard,
  GeneratedAcademicDocument,
  WorkspaceItem,
} from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { downloadAcademicDocx, downloadAcademicPdf } from '../utils/exportGenerators';
import { saveWorkspaceItem } from '../lib/firestoreService';

const DOC_TYPE_KEYS: AcademicDocType[] = [
  'kurs_ishi',
  'diplom_ishi',
  'magistr_dissertatsiya',
  'referat',
  'mustaqil_ish',
  'amaliy_ish',
  'laboratoriya_ishi',
  'esse',
  'ilmiy_maqola',
  'hisobot',
  'taqdimot_matni',
  'maruza_matni',
  'seminar_materiallari',
  'konspekt',
  'biznes_loyiha',
  'case_study',
  'research_proposal',
];

interface AcademicDocumentsViewProps {
  loadedWorkspaceItem?: WorkspaceItem | null;
}

export const AcademicDocumentsView: React.FC<AcademicDocumentsViewProps> = ({
  loadedWorkspaceItem,
}) => {
  const { firebaseUser, profile, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [docType, setDocType] = useState<AcademicDocType>('kurs_ishi');
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('');
  const [academicLevel, setAcademicLevel] = useState<AcademicLevel>('undergraduate');
  const [targetPages, setTargetPages] = useState(15);
  const [standard, setStandard] = useState<CitationStandard>('uz_dst');
  const [additionalInfo, setAdditionalInfo] = useState('');

  const [ministry, setMinistry] = useState('OʻZBEKISTON RESPUBLIKASI OLIY TAʼLIM, FAN VA INNOVATSIYALAR VAZIRLIGI');
  const [university, setUniversity] = useState(profile?.university || '');
  const [faculty, setFaculty] = useState(profile?.faculty || '');
  const [student, setStudent] = useState(profile?.displayName || '');
  const [group, setGroup] = useState('');
  const [supervisor, setSupervisor] = useState('');
  const [city, setCity] = useState('Toshkent');
  const [year, setYear] = useState('2026');

  const [docData, setDocData] = useState<GeneratedAcademicDocument | null>(null);
  const [savedDocId, setSavedDocId] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [regenKey, setRegenKey] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveDone, setSaveDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loadedWorkspaceItem && loadedWorkspaceItem.type === 'document') {
      const content = loadedWorkspaceItem.content as unknown as GeneratedAcademicDocument;
      if (content && content.topic) {
        setDocData(content);
        setSavedDocId(loadedWorkspaceItem.id);
      }
    }
  }, [loadedWorkspaceItem]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setLoading(true);
    setError(null);
    setSaveDone(false);
    setSavedDocId(undefined);

    try {
      const resp = await callAiApi<{
        document: Pick<
          GeneratedAcademicDocument,
          'introduction' | 'chapters' | 'conclusion' | 'references' | 'complianceNote'
        >;
      }>(
        '/api/documents/generate',
        {
          docType,
          topic: topic.trim(),
          subject: subject.trim(),
          academicLevel,
          language,
          targetPages,
          standard,
          additionalInfo: additionalInfo.trim(),
        },
        'documents'
      );

      setDocData({
        docType,
        topic: topic.trim(),
        subject: subject.trim(),
        academicLevel,
        language,
        targetPages,
        standard,
        universityMeta: {
          ministry,
          university,
          faculty,
          student,
          group,
          supervisor,
          city,
          year,
        },
        ...resp.document,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate document.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerateSection = async (ci: number, si: number) => {
    if (!docData || !firebaseUser) return;
    const sec = docData.chapters[ci]?.sections[si];
    if (!sec) return;
    const key = `${ci}_${si}`;
    setRegenKey(key);
    setError(null);

    try {
      const resp = await callAiApi<{ paragraphs: string[]; examples?: string }>(
        '/api/documents/regenerate-section',
        {
          topic: docData.topic,
          docType: docData.docType,
          sectionTitle: sec.title,
          language: docData.language,
          existingParagraphs: sec.paragraphs,
          instruction: 'Expand analytical depth, clarity, and academic examples.',
        },
        'documents_regen'
      );
      setDocData((prev) => {
        if (!prev) return prev;
        const nextChapters = prev.chapters.map((ch, cIdx) =>
          cIdx !== ci
            ? ch
            : {
                ...ch,
                sections: ch.sections.map((s, sIdx) =>
                  sIdx !== si
                    ? s
                    : { ...s, paragraphs: resp.paragraphs, examples: resp.examples || s.examples }
                ),
              }
        );
        return { ...prev, chapters: nextChapters };
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not regenerate section.');
    } finally {
      setRegenKey(null);
    }
  };

  const handleSave = async () => {
    if (!docData || !firebaseUser) return;
    setSaving(true);
    try {
      const id = await saveWorkspaceItem({
        id: savedDocId,
        userId: firebaseUser.uid,
        title: docData.topic,
        type: 'document',
        docSubtype: docData.docType,
        folder: t.docTypes[docData.docType] || 'Academic Documents',
        language: docData.language,
        summary: docData.introduction[0]?.slice(0, 280) || docData.topic,
        content: docData as unknown as Record<string, unknown>,
        versionNote: savedDocId ? 'Edited document' : 'Generated document',
      });
      setSavedDocId(id);
      setSaveDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save to workspace.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
        <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
          {t.nav.documents}
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          17 structured academic formats with verified Search-grounded references, inline section editing, and DOCX/PDF export.
        </p>

        <form onSubmit={handleGenerate} className="mt-6 space-y-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Document Type (17 formats)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {DOC_TYPE_KEYS.map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setDocType(key)}
                  className={`px-3 py-2 rounded-lg text-xs font-medium text-left border transition-colors cursor-pointer truncate ${
                    docType === key
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                  }`}
                >
                  {t.docTypes[key]}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Topic
              </label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Raqamli iqtisodiyot sharoitida tijorat banklarining kredit risklarini boshqarish"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Subject / Discipline
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g., Bank ishi / Econometrics"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Academic Level
              </label>
              <select
                value={academicLevel}
                onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100"
              >
                <option value="undergraduate">Undergraduate (Bakalavriat)</option>
                <option value="masters">Master's (Magistratura)</option>
                <option value="phd">PhD / Doctoral</option>
                <option value="researcher">Researcher</option>
                <option value="faculty">Faculty / Instructor</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Target Length (pages)
              </label>
              <input
                type="number"
                min={3}
                max={80}
                value={targetPages}
                onChange={(e) => setTargetPages(Number(e.target.value))}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Formatting & Citation Standard
              </label>
              <select
                value={standard}
                onChange={(e) => setStandard(e.target.value as CitationStandard)}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100"
              >
                <option value="uz_dst">Uzbekistan OTM Standard (Times New Roman 14pt)</option>
                <option value="apa">APA 7th Edition</option>
                <option value="ieee">IEEE</option>
                <option value="mla">MLA 9th Edition</option>
                <option value="chicago">Chicago</option>
                <option value="gost">GOST 7.1 / CIS Academic</option>
              </select>
            </div>
          </div>

          <details className="border border-slate-200 dark:border-slate-800 rounded-lg p-4">
            <summary className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Title Page & University Requirements (Optional)
            </summary>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <input
                type="text"
                value={ministry}
                onChange={(e) => setMinistry(e.target.value)}
                placeholder="Ministry"
                className="sm:col-span-2 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="text"
                value={university}
                onChange={(e) => setUniversity(e.target.value)}
                placeholder="University"
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="text"
                value={faculty}
                onChange={(e) => setFaculty(e.target.value)}
                placeholder="Faculty / Department"
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="text"
                value={student}
                onChange={(e) => setStudent(e.target.value)}
                placeholder="Student Name"
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="text"
                value={group}
                onChange={(e) => setGroup(e.target.value)}
                placeholder="Group"
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="text"
                value={supervisor}
                onChange={(e) => setSupervisor(e.target.value)}
                placeholder="Supervisor"
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="City"
                  className="w-1/2 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
                <input
                  type="text"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  placeholder="Year"
                  className="w-1/2 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
                />
              </div>
              <textarea
                rows={2}
                value={additionalInfo}
                onChange={(e) => setAdditionalInfo(e.target.value)}
                placeholder="Department guidelines, key terms, or empirical focus..."
                className="sm:col-span-2 lg:col-span-4 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
            </div>
          </details>

          <div className="flex items-center justify-between gap-4">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              References are retrieved via Google Search grounding and never fabricated.
            </p>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 cursor-pointer inline-flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              <FileText className="w-4 h-4" />
              {loading ? t.common.generating : t.common.generate}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </div>

      {/* Document Editor & Preview */}
      {docData && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.docTypes[docData.docType]} · {docData.standard.toUpperCase()} · {docData.language.toUpperCase()}
              </p>
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100 mt-0.5">
                {docData.topic}
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="px-3.5 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                {saveDone ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4" />}
                {saving ? t.common.saving : saveDone ? t.common.saved : t.common.save}
              </button>
              <button
                type="button"
                onClick={() => void downloadAcademicDocx(docData)}
                className="px-3.5 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold hover:opacity-90 cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                {t.common.downloadDocx}
              </button>
              <button
                type="button"
                onClick={() => downloadAcademicPdf(docData)}
                className="px-3.5 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                {t.common.downloadPdf}
              </button>
            </div>
          </div>

          {docData.complianceNote && (
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{docData.complianceNote}</span>
            </div>
          )}

          {/* Introduction */}
          <div className="space-y-2">
            <h4 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
              Introduction
            </h4>
            <textarea
              rows={5}
              value={docData.introduction.join('\n\n')}
              onChange={(e) =>
                setDocData({ ...docData, introduction: e.target.value.split(/\n\n+/).filter(Boolean) })
              }
              className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm leading-relaxed text-slate-800 dark:text-slate-200"
            />
          </div>

          {/* Chapters & Sections */}
          {docData.chapters.map((chapter, ci) => (
            <div key={chapter.id} className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
              <h4 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                {ci + 1}. {chapter.title}
              </h4>
              {chapter.sections.map((sec, si) => {
                const key = `${ci}_${si}`;
                return (
                  <div
                    key={sec.id}
                    className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg space-y-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <h5 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {ci + 1}.{si + 1}. {sec.title}
                      </h5>
                      <button
                        type="button"
                        disabled={regenKey === key}
                        onClick={() => void handleRegenerateSection(ci, si)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-md hover:bg-white dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${regenKey === key ? 'animate-spin' : ''}`} />
                        {regenKey === key ? t.common.generating : t.common.regenerate}
                      </button>
                    </div>
                    <textarea
                      rows={6}
                      value={sec.paragraphs.join('\n\n')}
                      onChange={(e) => {
                        const updated = e.target.value.split(/\n\n+/).filter(Boolean);
                        setDocData((prev) =>
                          !prev
                            ? prev
                            : {
                                ...prev,
                                chapters: prev.chapters.map((c, cI) =>
                                  cI !== ci
                                    ? c
                                    : {
                                        ...c,
                                        sections: c.sections.map((s, sI) =>
                                          sI !== si ? s : { ...s, paragraphs: updated }
                                        ),
                                      }
                                ),
                              }
                        );
                      }}
                      className="w-full p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm leading-relaxed text-slate-800 dark:text-slate-200"
                    />
                  </div>
                );
              })}
            </div>
          ))}

          {/* Conclusion */}
          <div className="space-y-2 pt-4 border-t border-slate-200 dark:border-slate-800">
            <h4 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
              Conclusion
            </h4>
            <textarea
              rows={4}
              value={docData.conclusion.join('\n\n')}
              onChange={(e) =>
                setDocData({ ...docData, conclusion: e.target.value.split(/\n\n+/).filter(Boolean) })
              }
              className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm leading-relaxed text-slate-800 dark:text-slate-200"
            />
          </div>

          {/* References */}
          <div className="space-y-2 pt-4 border-t border-slate-200 dark:border-slate-800">
            <h4 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
              References
            </h4>
            <ul className="space-y-2">
              {docData.references.map((ref, idx) => (
                <li
                  key={idx}
                  className="text-xs text-slate-700 dark:text-slate-300 flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg"
                >
                  <span>
                    {idx + 1}. {ref.citation}{' '}
                    {ref.url && (
                      <a
                        href={ref.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 dark:text-blue-400 underline break-all"
                      >
                        {ref.url}
                      </a>
                    )}
                  </span>
                  <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    {ref.verified ? 'Search-verified source' : 'Verify against library'}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
