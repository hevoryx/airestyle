import React, { useState } from 'react';
import { Check, Copy, Languages } from 'lucide-react';
import { SUPPORTED_LANGUAGES, type Language } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';

export const TranslatorWritingView: React.FC = () => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [sourceLang, setSourceLang] = useState<Language | 'auto'>('auto');
  const [targetLang, setTargetLang] = useState<Language>('en');
  const [action, setAction] = useState<'translate' | 'rewrite' | 'grammar' | 'spelling' | 'simplify'>('translate');
  const [style, setStyle] = useState<'academic' | 'formal' | 'informal'>('academic');
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [notes, setNotes] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleProcess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const resp = await callAiApi<{ outputText: string; notes: string[] }>(
        '/api/translate/process',
        {
          text: inputText,
          sourceLang,
          targetLang,
          action,
          style,
        },
        'translator'
      );
      setOutputText(resp.outputText);
      setNotes(resp.notes || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Translation failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!outputText) return;
    await navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <form
        onSubmit={handleProcess}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              {t.nav.translator}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Uzbek · Russian · English · Karakalpak · Kazakh — Academic translation, rewriting, grammar & spelling
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {(
              [
                ['translate', 'Translate'],
                ['rewrite', 'Rewrite'],
                ['grammar', 'Grammar'],
                ['spelling', 'Spelling'],
                ['simplify', 'Simplify'],
              ] as const
            ).map(([k, lbl]) => (
              <button
                key={k}
                type="button"
                onClick={() => setAction(k)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                  action === k
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                {lbl}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Source Language
            </label>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value as Language | 'auto')}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
            >
              <option value="auto">Auto-detect</option>
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.label})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Target Language
            </label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value as Language)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.label})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Writing Style
            </label>
            <select
              value={style}
              onChange={(e) => setStyle(e.target.value as 'academic' | 'formal' | 'informal')}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
            >
              <option value="academic">Academic & Scholarly</option>
              <option value="formal">Formal Professional</option>
              <option value="informal">Plain & Accessible</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            <textarea
              rows={10}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste academic abstract, essay paragraph, lecture text, or notes..."
              className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm leading-relaxed"
            />
            <p className="text-xs font-mono text-slate-500 tabular-nums">
              {inputText.trim() ? inputText.trim().split(/\s+/).length : 0} words · {inputText.length} chars
            </p>
          </div>

          <div className="space-y-2">
            <div className="relative">
              <textarea
                rows={10}
                readOnly
                value={outputText}
                placeholder="Processed output appears here..."
                className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm leading-relaxed"
              />
              {outputText && (
                <button
                  type="button"
                  onClick={() => void handleCopy()}
                  className="absolute top-2.5 right-2.5 px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md text-xs inline-flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? t.common.copied : t.common.copy}
                </button>
              )}
            </div>
            {notes.length > 0 && (
              <ul className="text-xs text-slate-600 dark:text-slate-400 list-disc pl-4 space-y-1">
                {notes.map((n, i) => (
                  <li key={i}>{n}</li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading || !inputText.trim()}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-2"
          >
            <Languages className="w-4 h-4" />
            {loading ? t.common.generating : 'Process Text'}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </form>
    </div>
  );
};
