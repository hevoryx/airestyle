import React, { useMemo, useState } from 'react';
import {
  Copy,
  Download,
  Edit3,
  ExternalLink,
  Folder,
  FolderOpen,
  History,
  RotateCcw,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import type {
  GeneratedAcademicDocument,
  Slide,
  WorkspaceItem,
  WorkspaceType,
  WorkspaceVersion,
} from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import {
  deleteWorkspaceItem,
  listWorkspaceVersions,
  saveWorkspaceItem,
  updateWorkspaceMeta,
} from '../lib/firestoreService';
import {
  downloadAcademicDocx,
  downloadAcademicPdf,
  downloadPresentationPdf,
} from '../utils/exportGenerators';
import { generatePPTX } from '../../utils/pptxGenerator';
import { getTheme } from '../../utils/themes';

interface WorkspaceFilesViewProps {
  workspaces: WorkspaceItem[];
  onOpenWorkspaceItem: (item: WorkspaceItem) => void;
}

export const WorkspaceFilesView: React.FC<WorkspaceFilesViewProps> = ({
  workspaces,
  onOpenWorkspaceItem,
}) => {
  const { firebaseUser, language } = useAuth();
  const t = UI_STRINGS[language];

  const [selectedFolder, setSelectedFolder] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<'all' | WorkspaceType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Edit / Rename modal state
  const [editingItem, setEditingItem] = useState<WorkspaceItem | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editFolder, setEditFolder] = useState('');
  const [editSummary, setEditSummary] = useState('');

  // Version History drawer state
  const [historyItem, setHistoryItem] = useState<WorkspaceItem | null>(null);
  const [versions, setVersions] = useState<WorkspaceVersion[]>([]);
  const [loadingVersions, setLoadingVersions] = useState(false);

  // Preview modal for analysis / note / resume / exam items
  const [previewItem, setPreviewItem] = useState<WorkspaceItem | null>(null);

  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const folders = useMemo(() => {
    const map = new Map<string, number>();
    workspaces.forEach((item) => {
      const f = item.folder || 'General';
      map.set(f, (map.get(f) || 0) + 1);
    });
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [workspaces]);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return workspaces.filter((item) => {
      if (selectedFolder !== 'ALL' && (item.folder || 'General') !== selectedFolder) return false;
      if (selectedType !== 'all' && item.type !== selectedType) return false;
      if (
        q &&
        !item.title.toLowerCase().includes(q) &&
        !(item.summary || '').toLowerCase().includes(q) &&
        !(item.folder || '').toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [workspaces, selectedFolder, selectedType, searchQuery]);

  const openEditModal = (item: WorkspaceItem) => {
    setEditingItem(item);
    setEditTitle(item.title);
    setEditFolder(item.folder || 'General');
    setEditSummary(item.summary || '');
    setError(null);
  };

  const handleSaveMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !editTitle.trim()) return;
    setBusyId(editingItem.id);
    try {
      await updateWorkspaceMeta(editingItem.id, {
        title: editTitle.trim(),
        folder: editFolder.trim() || 'General',
        summary: editSummary.trim(),
      });
      setEditingItem(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update project.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDuplicate = async (item: WorkspaceItem) => {
    if (!firebaseUser) return;
    setBusyId(item.id);
    setError(null);
    try {
      await saveWorkspaceItem({
        userId: firebaseUser.uid,
        title: `${item.title} (Copy)`,
        type: item.type,
        docSubtype: item.docSubtype,
        folder: item.folder || 'General',
        language: item.language,
        summary: item.summary,
        content: item.content,
        versionNote: `Duplicated from v${item.versionCount}`,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to duplicate project.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (id: string) => {
    setBusyId(id);
    setError(null);
    try {
      await deleteWorkspaceItem(id);
      setConfirmDeleteId(null);
      if (historyItem?.id === id) setHistoryItem(null);
      if (previewItem?.id === id) setPreviewItem(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete project.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDownload = async (item: WorkspaceItem, format: 'primary' | 'pdf') => {
    setBusyId(item.id);
    try {
      if (item.type === 'document') {
        const doc = item.content as unknown as GeneratedAcademicDocument;
        if (format === 'pdf') {
          downloadAcademicPdf(doc);
        } else {
          await downloadAcademicDocx(doc);
        }
        return;
      }

      if (item.type === 'presentation') {
        const content = item.content as { topic?: string; themeId?: string; slides?: Slide[] };
        const slides = content.slides || [];
        const theme = getTheme(content.themeId);
        if (format === 'pdf') {
          downloadPresentationPdf(content.topic || item.title, slides, theme);
        } else {
          await generatePPTX(content.topic || item.title, slides, theme);
        }
        return;
      }

      // Generic structured download for math / research / analysis / resume / note
      const formattedText = `${item.title}\nType: ${item.type} | Folder: ${item.folder}\n\n${JSON.stringify(
        item.content,
        null,
        2
      )}`;

      if (format === 'pdf') {
        const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(14);
        pdf.text(item.title.slice(0, 80), 18, 20);
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        const lines = pdf.splitTextToSize(formattedText, 175) as string[];
        let y = 30;
        for (const line of lines) {
          if (y > 278) {
            pdf.addPage();
            y = 18;
          }
          pdf.text(line, 18, y);
          y += 5;
        }
        pdf.save(`${item.title.replace(/[^a-zA-Z0-9_-]+/g, '_').slice(0, 50) || 'workspace'}.pdf`);
      } else {
        const blob = new Blob([formattedText], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${item.title.replace(/[^a-zA-Z0-9_-]+/g, '_').slice(0, 50) || 'workspace'}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1500);
      }
    } finally {
      setBusyId(null);
    }
  };

  const openVersionHistory = async (item: WorkspaceItem) => {
    if (!firebaseUser) return;
    setHistoryItem(item);
    setLoadingVersions(true);
    setVersions([]);
    try {
      const list = await listWorkspaceVersions(item.id, firebaseUser.uid);
      setVersions(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load version history.');
    } finally {
      setLoadingVersions(false);
    }
  };

  const restoreVersion = async (ver: WorkspaceVersion) => {
    if (!firebaseUser || !historyItem) return;
    setBusyId(ver.id);
    try {
      await saveWorkspaceItem({
        id: historyItem.id,
        userId: firebaseUser.uid,
        title: historyItem.title,
        type: historyItem.type,
        docSubtype: historyItem.docSubtype,
        folder: historyItem.folder,
        language: historyItem.language,
        summary: historyItem.summary,
        content: ver.content,
        versionNote: `Restored from v${ver.versionNumber}`,
      });
      const updated = await listWorkspaceVersions(historyItem.id, firebaseUser.uid);
      setVersions(updated);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to restore version.');
    } finally {
      setBusyId(null);
    }
  };

  const handleOpen = (item: WorkspaceItem) => {
    if (['document', 'presentation', 'math', 'research'].includes(item.type)) {
      onOpenWorkspaceItem(item);
    } else {
      setPreviewItem(item);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Folders Sidebar */}
        <aside className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
          <p className="px-2 text-xs font-semibold text-slate-500 dark:text-slate-400">Folders</p>
          <button
            type="button"
            onClick={() => setSelectedFolder('ALL')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm cursor-pointer ${
              selectedFolder === 'ALL'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <span className="inline-flex items-center gap-2 truncate">
              <FolderOpen className="w-4 h-4 shrink-0" />
              {t.common.all}
            </span>
            <span className="text-xs tabular-nums opacity-75">{workspaces.length}</span>
          </button>

          {folders.map(([folderName, count]) => (
            <button
              key={folderName}
              type="button"
              onClick={() => setSelectedFolder(folderName)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm cursor-pointer ${
                selectedFolder === folderName
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span className="inline-flex items-center gap-2 truncate">
                <Folder className="w-4 h-4 shrink-0" />
                {folderName}
              </span>
              <span className="text-xs tabular-nums opacity-75">{count}</span>
            </button>
          ))}
        </aside>

        {/* Main File Browser */}
        <div className="lg:col-span-9 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`${t.common.search}...`}
                className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500"
              />
            </div>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as 'all' | WorkspaceType)}
              className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
            >
              <option value="all">All Types</option>
              <option value="document">Academic Documents</option>
              <option value="presentation">Presentations</option>
              <option value="math">Math & Economics</option>
              <option value="research">Research Briefs</option>
              <option value="analysis">Document Analyses</option>
              <option value="resume">Resumes & CVs</option>
              <option value="note">Notes</option>
            </select>
          </div>

          {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}

          {filteredItems.length === 0 ? (
            <div className="py-16 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
              <FolderOpen className="w-9 h-9 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-sm text-slate-500 dark:text-slate-400">{t.dashboard.noProjects}</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredItems.map((item) => (
                <div key={item.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpen(item)}
                        className="text-sm font-semibold text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 text-left truncate cursor-pointer"
                      >
                        {item.title}
                      </button>
                      <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        v{item.versionCount}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.type} · {item.folder || 'General'} · {item.language.toUpperCase()}
                    </p>
                    {item.summary && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-1">
                        {item.summary}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpen(item)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg hover:opacity-90 cursor-pointer whitespace-nowrap"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Open
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDownload(item, 'primary')}
                      disabled={busyId === item.id}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {item.type === 'document' ? 'DOCX' : item.type === 'presentation' ? 'PPTX' : 'TXT'}
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDownload(item, 'pdf')}
                      disabled={busyId === item.id}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                    >
                      PDF
                    </button>
                    <button
                      type="button"
                      onClick={() => void openVersionHistory(item)}
                      className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                      title="Version History"
                    >
                      <History className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => openEditModal(item)}
                      className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                      title={t.common.edit}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDuplicate(item)}
                      disabled={busyId === item.id}
                      className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                      title={t.common.duplicate}
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    {confirmDeleteId === item.id ? (
                      <button
                        type="button"
                        onClick={() => void handleDelete(item.id)}
                        className="px-2 py-1 text-xs bg-red-600 text-white rounded-md cursor-pointer"
                      >
                        Confirm
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(item.id)}
                        className="p-1.5 text-slate-500 hover:text-red-600 cursor-pointer"
                        title={t.common.delete}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Rename / Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveMeta}
            className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Rename & Organize File
              </h3>
              <button type="button" onClick={() => setEditingItem(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Title</label>
              <input
                type="text"
                required
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Folder</label>
              <input
                type="text"
                required
                value={editFolder}
                onChange={(e) => setEditFolder(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Summary</label>
              <textarea
                rows={3}
                value={editSummary}
                onChange={(e) => setEditSummary(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-4 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                disabled={busyId === editingItem.id}
                className="px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer"
              >
                {t.common.save}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Version History Modal */}
      {historyItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Version History
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-sm">
                  {historyItem.title}
                </p>
              </div>
              <button type="button" onClick={() => setHistoryItem(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {loadingVersions ? (
                <p className="py-8 text-center text-sm text-slate-500">{t.common.loading}</p>
              ) : versions.length === 0 ? (
                <p className="py-8 text-center text-sm text-slate-500">No saved version snapshots yet.</p>
              ) : (
                versions.map((ver) => (
                  <div key={ver.id} className="py-3 flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                        Version {ver.versionNumber}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {ver.note || 'Snapshot'}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={busyId === ver.id}
                      onClick={() => void restoreVersion(ver)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Restore
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Inline Preview Modal for non-studio items */}
      {previewItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  {previewItem.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {previewItem.type} · {previewItem.folder}
                </p>
              </div>
              <button type="button" onClick={() => setPreviewItem(null)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <pre className="flex-1 overflow-auto p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-mono">
              {JSON.stringify(previewItem.content, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
