import type { Express, NextFunction, Request, Response } from 'express';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { initializeApp, getApps, getApp } from 'firebase-admin/app';
import { getAuth, type DecodedIdToken } from 'firebase-admin/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { createPlanPrompt, createRefineSlidePrompt, SYSTEM_INSTRUCTION_PLAN } from '../../utils/prompts.ts';
import { createCourseOutlinePrompt, createCoursePartPrompt, SYSTEM_INSTRUCTION_COURSE } from '../../utils/courseworkPrompts.ts';
import type { Language, Slide } from '../../types.ts';

const adminApp = getApps().length
  ? getApp()
  : initializeApp({ projectId: firebaseConfig.projectId });
const adminAuth = getAuth(adminApp);

const PRIMARY_MODEL = 'gemini-4-hydrogen';
const FALLBACK_MODEL = 'gemini-3.1-flash-lite';
const ALLOWED_LANGUAGES = new Set<Language>(['uz', 'ru', 'en', 'kaa', 'kk']);

const LANGUAGE_LABELS: Record<Language, string> = {
  uz: "Uzbek (Latin script, literary standard with oʻ and gʻ)",
  ru: 'Russian (academic standard)',
  en: 'English (academic standard)',
  kaa: 'Karakalpak (Latin script, Qaraqalpaqsha)',
  kk: 'Kazakh (Cyrillic script, Қазақ тілі)',
};

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
}

const rateBuckets = new Map<string, { count: number; resetAt: number }>();

const rateLimitMiddleware = (req: AuthRequest, res: Response, next: NextFunction) => {
  const key = req.user?.uid || req.ip || 'anon';
  const now = Date.now();
  const bucket = rateBuckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    rateBuckets.set(key, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  if (bucket.count >= 40) {
    res.status(429).json({ error: 'Rate limit exceeded. Please wait a minute before sending more requests.' });
    return;
  }
  bucket.count += 1;
  next();
};

export const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in with Google.' });
    return;
  }
  const token = header.slice(7).trim();
  if (!token) {
    res.status(401).json({ error: 'Authentication token is empty.' });
    return;
  }
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: 'Session expired or invalid token. Please sign in again.' });
  }
};

const getAiClient = (): GoogleGenAI => {
  const apiKey = process.env.GEMINI_API_KEY?.trim() || process.env.API_KEY?.trim();
  if (!apiKey) {
    const err = new Error(
      'Gemini API key is not configured on the server. Add GEMINI_API_KEY in Settings > Secrets.'
    ) as Error & { status?: number; code?: string };
    err.status = 503;
    err.code = 'MISSING_API_KEY';
    throw err;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
  });
};

const extractStatus = (err: unknown): number => {
  if (typeof err === 'object' && err !== null) {
    const e = err as { status?: number; statusCode?: number; code?: number | string };
    if (typeof e.status === 'number') return e.status;
    if (typeof e.statusCode === 'number') return e.statusCode;
    if (typeof e.code === 'number') return e.code;
  }
  return 500;
};

const formatGeminiError = (err: unknown): { status: number; message: string } => {
  const status = extractStatus(err);
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes('MISSING_API_KEY') || (err as { code?: string })?.code === 'MISSING_API_KEY') {
    return { status: 503, message: 'Gemini API key is not configured in Settings > Secrets.' };
  }
  if (status === 401 || status === 403 || raw.includes('API_KEY_INVALID') || raw.includes('PERMISSION_DENIED')) {
    return { status: status === 403 ? 403 : 401, message: 'Gemini API key authentication failed. Check Settings > Secrets.' };
  }
  if (status === 429 || raw.includes('RESOURCE_EXHAUSTED')) {
    return { status: 429, message: 'Gemini rate limit or quota reached. Please wait briefly and try again.' };
  }
  if (status === 404 || raw.includes('NOT_FOUND')) {
    return { status: 502, message: 'Requested Gemini model is currently unavailable.' };
  }
  if (err instanceof SyntaxError) {
    return { status: 502, message: 'AI returned malformed structured output. Please try again.' };
  }
  return { status: status >= 400 && status < 600 ? status : 500, message: raw || 'AI request failed.' };
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const generateWithRetry = async <T>(
  run: (model: string) => Promise<T>,
  preferredModel = PRIMARY_MODEL
): Promise<{ result: T; model: string }> => {
  const tryModel = async (model: string) => {
    let lastErr: unknown;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        return await run(model);
      } catch (err) {
        lastErr = err;
        const status = extractStatus(err);
        if ((status === 429 || status >= 500) && attempt < 2) {
          await sleep(450 * attempt);
          continue;
        }
        throw err;
      }
    }
    throw lastErr;
  };

  try {
    const result = await tryModel(preferredModel);
    return { result, model: preferredModel };
  } catch (err) {
    const status = extractStatus(err);
    const fallback = preferredModel === PRIMARY_MODEL ? FALLBACK_MODEL : PRIMARY_MODEL;
    if (status === 429 || status === 503 || status === 404) {
      const result = await tryModel(fallback);
      return { result, model: fallback };
    }
    throw err;
  }
};

const stripJsonFences = (text: string): string => {
  const trimmed = text.trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
};

const safeLang = (lang: unknown): Language =>
  typeof lang === 'string' && ALLOWED_LANGUAGES.has(lang as Language) ? (lang as Language) : 'uz';

const getGroundingSources = (response: unknown): { title: string; uri: string }[] => {
  const candidates = (response as { candidates?: Array<{ groundingMetadata?: { groundingChunks?: Array<{ web?: { uri?: string; title?: string } }> } }> })?.candidates;
  const chunks = candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (!Array.isArray(chunks)) return [];
  const seen = new Set<string>();
  const out: { title: string; uri: string }[] = [];
  for (const chunk of chunks) {
    const uri = chunk?.web?.uri;
    const title = chunk?.web?.title;
    if (uri && !seen.has(uri)) {
      seen.add(uri);
      out.push({ title: title || uri, uri });
    }
  }
  return out;
};

const ALLOWED_THEMES = [
  'minimalist_light',
  'academic_navy',
  'corporate_slate',
  'modern_blue',
  'minimal_dark',
  'nature_green',
  'scientific_cyan',
  'midnight_gold',
];

const ALLOWED_LAYOUTS = [
  'title',
  'split_left',
  'split_right',
  'minimal_typography',
  'timeline_flow',
  'comparison_grid',
  'editorial_spotlight',
];

const slideSchema = {
  type: Type.OBJECT,
  properties: {
    sectionTag: { type: Type.STRING },
    title: { type: Type.STRING },
    content: { type: Type.ARRAY, items: { type: Type.STRING } },
    layout: { type: Type.STRING, enum: ALLOWED_LAYOUTS },
    visualMotif: { type: Type.STRING, enum: ['orbital', 'waves', 'nodes', 'peaks', 'grid', 'prism'] },
    visual: {
      type: Type.OBJECT,
      properties: {
        kind: { type: Type.STRING, enum: ['stat', 'steps', 'highlights', 'quote', 'timeline', 'comparison', 'chart', 'table'] },
        heading: { type: Type.STRING },
        items: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              value: { type: Type.STRING },
              numericValue: { type: Type.NUMBER },
            },
            required: ['label', 'value'],
          },
        },
        tableHeaders: { type: Type.ARRAY, items: { type: Type.STRING } },
        tableRows: { type: Type.ARRAY, items: { type: Type.ARRAY, items: { type: Type.STRING } } },
      },
      required: ['kind', 'heading', 'items'],
    },
    speakerNotes: { type: Type.STRING },
  },
  required: ['sectionTag', 'title', 'content', 'layout', 'visualMotif', 'visual', 'speakerNotes'],
};

export function registerAiRoutes(app: Express): void {
  app.get('/api/health', (_req, res) => {
    const hasApiKey = Boolean(process.env.GEMINI_API_KEY?.trim() || process.env.API_KEY?.trim());
    res.json({ ok: true, hasApiKey, model: PRIMARY_MODEL });
  });

  /* ---------------------------------------------------------------- */
  /* 1. Core AI Assistant                                             */
  /* ---------------------------------------------------------------- */
  app.post('/api/assistant/chat', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { message, history, language, explanationMode, rememberContext, attachments } = req.body ?? {};
      if (typeof message !== 'string' || !message.trim() || message.length > 15000) {
        res.status(400).json({ error: 'Message must be a non-empty string up to 15,000 characters.' });
        return;
      }

      const lang = safeLang(language);
      const mode = explanationMode === 'advanced' ? 'advanced' : 'simple';
      const ai = getAiClient();

      const systemInstruction = `You are AI University Assistant, a rigorous academic mentor for university students, master's/PhD candidates, and researchers in Uzbekistan, Central Asia, and globally.
Respond strictly in ${LANGUAGE_LABELS[lang]}.
Explanation depth: ${mode === 'advanced' ? 'Advanced academic & technical rigor with formal terminology, derivations, and methodological nuance.' : 'Clear, step-by-step accessible explanations suitable for building deep intuition.'}
HONESTY & ANTI-HALLUCINATION RULES:
- Never fabricate facts, statistics, DOIs, authors, journal names, or page numbers.
- If uncertain or if verification is required, explicitly state your uncertainty.
- When uploaded document text or image/PDF attachments are provided, strictly distinguish what comes directly from the uploaded material versus general academic knowledge.
- Also determine whether another specialized workspace module fits the request (one of: "documents", "presentations", "solver", "analyzer", "exams", "translator", "research", "planner", "tools", or null).
Return valid JSON matching the schema.`;

      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

      if (rememberContext && Array.isArray(history) && history.length > 0) {
        const recent = history
          .slice(-8)
          .filter((h: unknown): h is { role: string; text: string } => typeof h === 'object' && h !== null && typeof (h as { text?: unknown }).text === 'string')
          .map((h) => `${h.role === 'assistant' ? 'Assistant' : 'Student'}: ${h.text.slice(0, 2000)}`)
          .join('\n\n');
        if (recent) {
          parts.push({ text: `Conversation context (student permitted memory):\n${recent}` });
        }
      }

      if (Array.isArray(attachments)) {
        for (const att of attachments.slice(0, 3)) {
          if (att && typeof att === 'object') {
            if (typeof att.extractedText === 'string' && att.extractedText.trim()) {
              parts.push({
                text: `Uploaded file "${String(att.fileName || 'document').slice(0, 120)}":\n${att.extractedText.slice(0, 40000)}`,
              });
            } else if (typeof att.base64Data === 'string' && typeof att.mimeType === 'string') {
              parts.push({
                inlineData: {
                  mimeType: att.mimeType,
                  data: att.base64Data,
                },
              });
            }
          }
        }
      }

      parts.push({ text: `Student request:\n${message.trim()}` });

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: { parts },
          config: {
            systemInstruction,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                reply: { type: Type.STRING },
                recommendedTool: {
                  type: Type.STRING,
                  enum: ['none', 'documents', 'presentations', 'solver', 'analyzer', 'exams', 'translator', 'research', 'planner', 'tools'],
                },
              },
              required: ['reply', 'recommendedTool'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}')) as {
        reply?: string;
        recommendedTool?: string;
      };

      res.json({
        reply: parsed.reply || response.text || '',
        recommendedTool: parsed.recommendedTool && parsed.recommendedTool !== 'none' ? parsed.recommendedTool : undefined,
        usageStats: {
          model,
          totalTokens: response.usageMetadata?.totalTokenCount || 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 2. Academic Document Generator (17 types, Search-grounded refs)  */
  /* ---------------------------------------------------------------- */
  app.post('/api/documents/generate', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { docType, topic, subject, academicLevel, language, targetPages, standard, additionalInfo } = req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.length > 300) {
        res.status(400).json({ error: 'Topic must be between 3 and 300 characters.' });
        return;
      }

      const lang = safeLang(language);
      const pages = Math.max(3, Math.min(80, Math.round(Number(targetPages) || 15)));
      const chapterCount = pages <= 8 ? 2 : pages <= 25 ? 3 : 4;
      const ai = getAiClient();

      // Step 1: Search-grounded real verifiable references (never fabricate!)
      let groundingSources: { title: string; uri: string }[] = [];
      let groundedSummary = '';
      try {
        const searchResp = await generateWithRetry((m) =>
          ai.models.generateContent({
            model: m,
            contents: `Find real, authoritative academic sources, textbooks, peer-reviewed papers, or official institutional publications about: "${topic.trim()}" (subject: ${String(subject || 'General').slice(0, 120)}). List exact titles, authors/organizations if visible, and years without inventing anything.`,
            config: {
              tools: [{ googleSearch: {} }],
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            },
          })
        );
        groundingSources = getGroundingSources(searchResp.result);
        groundedSummary = (searchResp.result.text || '').slice(0, 4000);
      } catch {
        groundingSources = [];
      }

      // Step 2: Structured full academic document
      const systemInstruction = `You are a senior university professor and academic writing specialist.
Write strictly in ${LANGUAGE_LABELS[lang]}.
Document type: ${String(docType || 'kurs_ishi')}.
Academic level: ${String(academicLevel || 'undergraduate')}.
Citation standard: ${String(standard || 'uz_dst').toUpperCase()}.
CRITICAL ACADEMIC INTEGRITY RULES:
- Create logically connected chapters (${chapterCount} chapters, 2 sections each) with substantial analytical paragraphs, concrete examples, introduction, and conclusion.
- For references: use ONLY verifiable sources from the retrieved search results below or standard foundational works you are certain exist. NEVER invent DOI numbers, fake page numbers, or nonexistent authors. Include a clear complianceNote stating that formatting should be checked against the student's specific university/department handbook.`;

      const prompt = `Topic: "${topic.trim()}"
Subject: "${String(subject || '').slice(0, 150)}"
Target length: ~${pages} pages
Additional requirements: "${String(additionalInfo || '').slice(0, 1000)}"
Retrieved web/scholarly context:\n${groundedSummary || 'No external search snippets retrieved; clearly mark references that require student verification.'}
Retrieved URLs:\n${groundingSources.map((s) => `- ${s.title}: ${s.uri}`).join('\n') || 'None'}

Generate the complete structured academic document as JSON matching the schema.`;

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: prompt,
          config: {
            systemInstruction,
            thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                introduction: { type: Type.ARRAY, items: { type: Type.STRING } },
                chapters: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      sections: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            title: { type: Type.STRING },
                            paragraphs: { type: Type.ARRAY, items: { type: Type.STRING } },
                            examples: { type: Type.STRING },
                          },
                          required: ['title', 'paragraphs'],
                        },
                      },
                    },
                    required: ['title', 'sections'],
                  },
                },
                conclusion: { type: Type.ARRAY, items: { type: Type.STRING } },
                references: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      citation: { type: Type.STRING },
                      url: { type: Type.STRING },
                      verified: { type: Type.BOOLEAN },
                    },
                    required: ['citation', 'verified'],
                  },
                },
                complianceNote: { type: Type.STRING },
              },
              required: ['introduction', 'chapters', 'conclusion', 'references', 'complianceNote'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}')) as {
        introduction?: string[];
        chapters?: Array<{ title: string; sections: Array<{ title: string; paragraphs: string[]; examples?: string }> }>;
        conclusion?: string[];
        references?: Array<{ citation: string; url?: string; verified: boolean }>;
        complianceNote?: string;
      };

      const chapters = (parsed.chapters || []).map((ch, ci) => ({
        id: `ch_${ci + 1}`,
        title: ch.title,
        sections: (ch.sections || []).map((sec, si) => ({
          id: `sec_${ci + 1}_${si + 1}`,
          title: sec.title,
          paragraphs: sec.paragraphs || [],
          examples: sec.examples || '',
        })),
      }));

      // Merge any verified grounding URLs if refs didn't carry them
      const refs = (parsed.references || []).map((r) => ({
        citation: r.citation,
        url: r.url || undefined,
        verified: Boolean(r.verified && r.url && groundingSources.some((g) => g.uri === r.url)),
      }));
      for (const src of groundingSources.slice(0, 4)) {
        if (!refs.some((r) => r.url === src.uri)) {
          refs.push({ citation: src.title, url: src.uri, verified: true });
        }
      }

      res.json({
        document: {
          introduction: parsed.introduction || [],
          chapters,
          conclusion: parsed.conclusion || [],
          references: refs,
          complianceNote: parsed.complianceNote || '',
        },
        usageStats: {
          model,
          totalTokens: response.usageMetadata?.totalTokenCount || 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/documents/regenerate-section', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, docType, sectionTitle, instruction, language, existingParagraphs } = req.body ?? {};
      if (typeof topic !== 'string' || typeof sectionTitle !== 'string') {
        res.status(400).json({ error: 'Topic and section title are required.' });
        return;
      }
      const lang = safeLang(language);
      const ai = getAiClient();

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Document topic: "${topic.slice(0, 300)}" (${String(docType || 'academic')}).
Section title: "${sectionTitle.slice(0, 200)}".
Existing text:\n${Array.isArray(existingParagraphs) ? existingParagraphs.join('\n\n').slice(0, 4000) : ''}
User instruction: "${String(instruction || 'Expand with deeper academic analysis and a concrete example').slice(0, 500)}".
Write in ${LANGUAGE_LABELS[lang]}.`,
          config: {
            systemInstruction: `Rewrite and strengthen this academic section in ${LANGUAGE_LABELS[lang]}. Never invent fake citations or statistics.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                paragraphs: { type: Type.ARRAY, items: { type: Type.STRING } },
                examples: { type: Type.STRING },
              },
              required: ['paragraphs'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json({
        paragraphs: parsed.paragraphs || [],
        examples: parsed.examples || '',
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 3. Presentation Generator (7 Styles, Charts, Tables, Notes)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/presentation/plan', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, slideCount, planCount, language, style, additionalInfo } = req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 2 || topic.length > 300) {
        res.status(400).json({ error: 'Topic must be between 2 and 300 characters.' });
        return;
      }
      const parsedSlides = Math.max(3, Math.min(25, Math.round(Number(slideCount) || 8)));
      const parsedPlans = Math.max(2, Math.min(8, Math.round(Number(planCount) || 4)));
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const safeInfo = `${style ? `Design style: ${String(style)}. ` : ''}${typeof additionalInfo === 'string' ? additionalInfo.trim().slice(0, 900) : ''}
Output language must strictly be: ${LANGUAGE_LABELS[lang]}. Include at least one 'chart' visual (with numericValue for bar/chart rendering) and one 'table' visual (with tableHeaders and tableRows) where appropriate for data/comparison.`;

      const ai = getAiClient();
      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: createPlanPrompt(topic.trim(), parsedSlides, parsedPlans, baseLang, safeInfo),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_PLAN(baseLang) + `\nWrite ALL slide text in ${LANGUAGE_LABELS[lang]}.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                themeId: { type: Type.STRING, enum: ALLOWED_THEMES },
                slides: { type: Type.ARRAY, items: slideSchema },
              },
              required: ['themeId', 'slides'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}')) as { themeId?: string; slides?: Slide[] };
      res.json({
        themeId: parsed.themeId || 'academic_navy',
        slides: Array.isArray(parsed.slides) ? parsed.slides : [],
        usageStats: {
          model,
          inputTokens: response.usageMetadata?.promptTokenCount || 0,
          outputTokens: response.usageMetadata?.candidatesTokenCount || 0,
          totalTokens: response.usageMetadata?.totalTokenCount || 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/presentation/refine-slide', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, slide, instruction, language } = req.body ?? {};
      if (typeof topic !== 'string' || !slide || typeof instruction !== 'string') {
        res.status(400).json({ error: 'Topic, slide, and instruction are required.' });
        return;
      }
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const ai = getAiClient();

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: createRefineSlidePrompt(topic.slice(0, 300), slide as Slide, instruction.slice(0, 400), baseLang),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_PLAN(baseLang) + `\nOutput strictly in ${LANGUAGE_LABELS[lang]}.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: slideSchema,
          },
        })
      );

      const refined = JSON.parse(stripJsonFences(response.text || '{}')) as Slide;
      res.json({
        slide: refined,
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* Legacy coursework endpoints retained cleanly */
  app.post('/api/coursework/outline', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, pages, chapterCount, language, additionalInfo } = req.body ?? {};
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const ai = getAiClient();
      const { result: response } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: createCourseOutlinePrompt(String(topic || ''), Number(pages) || 20, Number(chapterCount) || 2, 2, baseLang, additionalInfo),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_COURSE(baseLang),
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
          },
        })
      );
      res.json({ outline: JSON.parse(stripJsonFences(response.text || '{}')) });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/coursework/part', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const body = req.body ?? {};
      const lang = safeLang(body.language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const ai = getAiClient();
      const { result: response } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: createCoursePartPrompt({ ...body, language: baseLang }),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_COURSE(baseLang),
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
          },
        })
      );
      const parsed = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json(parsed);
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 4. Mathematics & Economics Solver (OCR + Dual Verification)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/solver/solve', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { subject, problemText, imageBase64, imageMimeType, language } = req.body ?? {};
      if ((!problemText || !String(problemText).trim()) && !imageBase64) {
        res.status(400).json({ error: 'Provide a problem statement or upload an image of a formula/problem.' });
        return;
      }

      const lang = safeLang(language);
      const ai = getAiClient();

      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];
      if (typeof imageBase64 === 'string' && typeof imageMimeType === 'string') {
        parts.push({ inlineData: { mimeType: imageMimeType, data: imageBase64 } });
      }
      parts.push({
        text: `Subject: ${String(subject || 'mathematics')}.
Language for all explanations: ${LANGUAGE_LABELS[lang]}.
Problem input: ${String(problemText || 'Read and extract the mathematical/economic problem from the attached image carefully.').slice(0, 8000)}

INSTRUCTIONS:
1. Extract the exact mathematical or economic expression cleanly.
2. Solve step by step, explaining every calculation clearly.
3. Provide valid LaTeX strings for formulaLatex and finalAnswerLatex (without surrounding $ signs).
4. Perform an INDEPENDENT verification pass (e.g., substituting solutions back, checking units/equilibrium conditions, checking derivatives/integrals or accounting balances). List any detected errors in the input or ambiguities.
5. NEVER present an unverified calculation as verified! If ambiguous or missing data prevents certainty, set verified=false and explain in uncertaintyNote.
6. When applicable (functions, supply/demand, cashflows, distributions), provide graphPoints and/or tableData.`,
      });

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: { parts },
          config: {
            systemInstruction: `You are a rigorous mathematics, statistics, finance, and economics problem solver. Explain in ${LANGUAGE_LABELS[lang]}. Perform independent mathematical verification before finalizing.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                extractedExpression: { type: Type.STRING },
                steps: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      stepNumber: { type: Type.INTEGER },
                      title: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                      formulaLatex: { type: Type.STRING },
                      intermediateResult: { type: Type.STRING },
                    },
                    required: ['stepNumber', 'title', 'explanation', 'formulaLatex', 'intermediateResult'],
                  },
                },
                independentVerification: {
                  type: Type.OBJECT,
                  properties: {
                    verified: { type: Type.BOOLEAN },
                    method: { type: Type.STRING },
                    auditNote: { type: Type.STRING },
                    detectedErrors: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['verified', 'method', 'auditNote', 'detectedErrors'],
                },
                finalAnswer: { type: Type.STRING },
                finalAnswerLatex: { type: Type.STRING },
                tableData: {
                  type: Type.OBJECT,
                  properties: {
                    headers: { type: Type.ARRAY, items: { type: Type.STRING } },
                    rows: { type: Type.ARRAY, items: { type: Type.ARRAY, items: { type: Type.STRING } } },
                  },
                  required: ['headers', 'rows'],
                },
                graphPoints: {
                  type: Type.OBJECT,
                  properties: {
                    xLabel: { type: Type.STRING },
                    yLabel: { type: Type.STRING },
                    seriesName: { type: Type.STRING },
                    points: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          x: { type: Type.NUMBER },
                          y: { type: Type.NUMBER },
                          label: { type: Type.STRING },
                        },
                        required: ['x', 'y'],
                      },
                    },
                  },
                  required: ['xLabel', 'yLabel', 'seriesName', 'points'],
                },
                uncertaintyNote: { type: Type.STRING },
              },
              required: ['extractedExpression', 'steps', 'independentVerification', 'finalAnswer', 'finalAnswerLatex'],
            },
          },
        })
      );

      const solution = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json({
        solution: { subject: String(subject || 'mathematics'), ...solution },
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 5. AI Document Analyzer (PDF/DOCX/XLSX/PPTX/JPG/PNG + OCR)       */
  /* ---------------------------------------------------------------- */
  app.post('/api/analyzer/analyze', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { fileName, mimeType, extractedText, base64Data, language } = req.body ?? {};
      if (!extractedText && !base64Data) {
        res.status(400).json({ error: 'Uploaded file content is required.' });
        return;
      }
      const lang = safeLang(language);
      const ai = getAiClient();

      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];
      if (typeof base64Data === 'string' && typeof mimeType === 'string') {
        parts.push({ inlineData: { mimeType, data: base64Data } });
      }
      if (typeof extractedText === 'string' && extractedText.trim()) {
        parts.push({ text: `Document text from "${String(fileName || 'file')}":\n${extractedText.slice(0, 60000)}` });
      }
      parts.push({
        text: `Analyze this uploaded document thoroughly in ${LANGUAGE_LABELS[lang]}.
If it is a scanned PDF or image, perform accurate OCR first and provide an extractedTextPreview.
Produce:
1. detected structure (heading + summary)
2. executiveSummary
3. keyFindings
4. studyNotes (concise revision notes derived strictly from the document)
5. extractedQA (questions and answers found or directly supported by the document, citing sourceLocation)
6. quizPreview (5 MCQs grounded strictly in the uploaded document)
7. sourceBoundaryNotice explaining what was directly found in the file vs any general context.`,
      });

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: { parts },
          config: {
            systemInstruction: `You are an academic document analyzer. Always distinguish facts directly extracted from the uploaded file from external background knowledge. Respond in ${LANGUAGE_LABELS[lang]}.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                extractedTextPreview: { type: Type.STRING },
                structure: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      heading: { type: Type.STRING },
                      summary: { type: Type.STRING },
                    },
                    required: ['heading', 'summary'],
                  },
                },
                executiveSummary: { type: Type.STRING },
                keyFindings: { type: Type.ARRAY, items: { type: Type.STRING } },
                studyNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
                extractedQA: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      question: { type: Type.STRING },
                      answer: { type: Type.STRING },
                      sourceLocation: { type: Type.STRING },
                    },
                    required: ['question', 'answer', 'sourceLocation'],
                  },
                },
                quizPreview: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctIndex: { type: Type.INTEGER },
                      explanation: { type: Type.STRING },
                    },
                    required: ['question', 'options', 'correctIndex', 'explanation'],
                  },
                },
                sourceBoundaryNotice: { type: Type.STRING },
              },
              required: [
                'extractedTextPreview',
                'structure',
                'executiveSummary',
                'keyFindings',
                'studyNotes',
                'extractedQA',
                'quizPreview',
                'sourceBoundaryNotice',
              ],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json({
        analysis: {
          fileName: String(fileName || 'document'),
          fileType: String(mimeType || 'unknown'),
          ...parsed,
        },
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/analyzer/ask', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { question, documentContext, base64Data, mimeType, language } = req.body ?? {};
      if (typeof question !== 'string' || !question.trim()) {
        res.status(400).json({ error: 'Question is required.' });
        return;
      }
      const lang = safeLang(language);
      const ai = getAiClient();
      const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];
      if (typeof base64Data === 'string' && typeof mimeType === 'string') {
        parts.push({ inlineData: { mimeType, data: base64Data } });
      }
      if (typeof documentContext === 'string' && documentContext.trim()) {
        parts.push({ text: `Uploaded document content:\n${documentContext.slice(0, 50000)}` });
      }
      parts.push({
        text: `Answer this question in ${LANGUAGE_LABELS[lang]}: "${question.trim()}". Explicitly separate [From Uploaded Document] and [External Academic Context]. If not answered in the document, say so clearly.`,
      });

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: { parts },
          config: { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } },
        })
      );

      res.json({
        answer: response.text || '',
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 6. Test & Exam System                                            */
  /* ---------------------------------------------------------------- */
  app.post('/api/exam/generate', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, subject, sourceText, questionCount, language, difficulty } = req.body ?? {};
      if ((!topic || !String(topic).trim()) && (!sourceText || !String(sourceText).trim())) {
        res.status(400).json({ error: 'Provide a topic or upload study material.' });
        return;
      }
      const lang = safeLang(language);
      const count = Math.max(4, Math.min(20, Math.round(Number(questionCount) || 8)));
      const ai = getAiClient();

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Create an exam preparation bundle in ${LANGUAGE_LABELS[lang]}.
Topic: "${String(topic || 'Uploaded Material').slice(0, 200)}"
Subject: "${String(subject || 'General').slice(0, 120)}"
Difficulty: "${String(difficulty || 'university')}"
Question count: ${count} (include a balanced mix of "mcq", "true_false", and "open" questions)
Also create 8 flashcards and a 5-day exam preparation plan.
${sourceText ? `Base questions strictly on this uploaded material:\n${String(sourceText).slice(0, 40000)}` : ''}`,
          config: {
            systemInstruction: `You are a university examiner. Write clearly in ${LANGUAGE_LABELS[lang]}. Every question must include a clear explanation.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      type: { type: Type.STRING, enum: ['mcq', 'true_false', 'open'] },
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctAnswer: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                      topicTag: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'question', 'correctAnswer', 'explanation', 'topicTag'],
                  },
                },
                flashcards: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      front: { type: Type.STRING },
                      back: { type: Type.STRING },
                      hint: { type: Type.STRING },
                    },
                    required: ['id', 'front', 'back'],
                  },
                },
                prepPlan: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      day: { type: Type.STRING },
                      focus: { type: Type.STRING },
                      tasks: { type: Type.ARRAY, items: { type: Type.STRING } },
                    },
                    required: ['day', 'focus', 'tasks'],
                  },
                },
              },
              required: ['questions', 'flashcards', 'prepPlan'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json({
        exam: {
          topic: String(topic || 'Study Material'),
          subject: String(subject || ''),
          ...parsed,
        },
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 7. Translation & Writing Tools                                   */
  /* ---------------------------------------------------------------- */
  app.post('/api/translate/process', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { text, sourceLang, targetLang, action, style } = req.body ?? {};
      if (typeof text !== 'string' || !text.trim() || text.length > 30000) {
        res.status(400).json({ error: 'Text must be between 1 and 30,000 characters.' });
        return;
      }
      const src = sourceLang === 'auto' ? 'Auto-detect' : LANGUAGE_LABELS[safeLang(sourceLang)];
      const tgt = LANGUAGE_LABELS[safeLang(targetLang)];
      const ai = getAiClient();

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Action: ${String(action || 'translate')}
Source language: ${src}
Target language: ${tgt}
Tone / Style: ${String(style || 'academic')}
Input text:\n${text}

Preserve original meaning, domain terminology, and paragraph structure.`,
          config: {
            systemInstruction: `You are an expert academic translator and editor fluent in Uzbek, Russian, English, Karakalpak, and Kazakh. Return JSON with outputText, notes (key edits or terminology notes), and corrections (list of grammar/spelling improvements if applicable).`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                outputText: { type: Type.STRING },
                notes: { type: Type.ARRAY, items: { type: Type.STRING } },
                detectedSource: { type: Type.STRING },
              },
              required: ['outputText', 'notes'],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(response.text || '{}'));
      res.json({
        ...parsed,
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 8. AI Research Assistant (Search-Grounded + Real Citations)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/research/explore', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, discipline, language, claimsToAudit } = req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.length > 400) {
        res.status(400).json({ error: 'Research topic must be between 3 and 400 characters.' });
        return;
      }
      const lang = safeLang(language);
      const ai = getAiClient();

      // Step 1: Google Search grounding for real academic sources
      const searchResp = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Search for real peer-reviewed studies, institutional reports, and academic papers on: "${topic.trim()}" (discipline: ${String(discipline || 'General').slice(0, 100)}). Summarize key real studies found, their methodologies, and limitations.`,
          config: {
            tools: [{ googleSearch: {} }],
            thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
          },
        })
      );

      const groundingSources = getGroundingSources(searchResp.result);
      const groundedText = (searchResp.result.text || '').slice(0, 6000);

      // Step 2: Structured synthesis strictly separating verified search sources vs suggested research directions
      const { result: structResp, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Topic: "${topic.trim()}"
Language: ${LANGUAGE_LABELS[lang]}
Grounded search findings:\n${groundedText}
Retrieved verified URLs:\n${groundingSources.map((g, i) => `${i + 1}. ${g.title} — ${g.uri}`).join('\n') || 'None'}
${claimsToAudit ? `Claims to audit for support:\n${String(claimsToAudit).slice(0, 3000)}` : ''}

Produce JSON matching schema. For verifiedSources, use ONLY sources from the retrieved verified URLs above (never fabricate DOIs, authors, or citations). Format APA, MLA, Chicago, and IEEE citations accurately from the retrieved title/URL/date (mark unknown authors/years cleanly rather than guessing). Put AI-proposed next avenues in suggestedDirections.`,
          config: {
            systemInstruction: `You are a rigorous academic research methodologist. Write in ${LANGUAGE_LABELS[lang]}. NEVER invent publications, DOIs, or authors.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                researchQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
                hypotheses: { type: Type.ARRAY, items: { type: Type.STRING } },
                literatureSynthesis: { type: Type.STRING },
                studyComparisons: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      studyTitle: { type: Type.STRING },
                      methodology: { type: Type.STRING },
                      keyFindings: { type: Type.STRING },
                      limitations: { type: Type.STRING },
                    },
                    required: ['studyTitle', 'methodology', 'keyFindings', 'limitations'],
                  },
                },
                unsupportedClaimsAudit: { type: Type.ARRAY, items: { type: Type.STRING } },
                verifiedSources: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      url: { type: Type.STRING },
                      snippet: { type: Type.STRING },
                      citations: {
                        type: Type.OBJECT,
                        properties: {
                          apa: { type: Type.STRING },
                          mla: { type: Type.STRING },
                          chicago: { type: Type.STRING },
                          ieee: { type: Type.STRING },
                        },
                        required: ['apa', 'mla', 'chicago', 'ieee'],
                      },
                    },
                    required: ['title', 'url', 'citations'],
                  },
                },
                suggestedDirections: { type: Type.ARRAY, items: { type: Type.STRING } },
                integrityNotice: { type: Type.STRING },
              },
              required: [
                'researchQuestions',
                'hypotheses',
                'literatureSynthesis',
                'studyComparisons',
                'unsupportedClaimsAudit',
                'verifiedSources',
                'suggestedDirections',
                'integrityNotice',
              ],
            },
          },
        })
      );

      const parsed = JSON.parse(stripJsonFences(structResp.text || '{}'));
      res.json({
        research: { topic: topic.trim(), ...parsed },
        usageStats: {
          model,
          totalTokens:
            (searchResp.result.usageMetadata?.totalTokenCount || 0) +
            (structResp.usageMetadata?.totalTokenCount || 0),
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  /* ---------------------------------------------------------------- */
  /* 9. Career, Resume & Admissions Assistant                         */
  /* ---------------------------------------------------------------- */
  app.post('/api/career/assist', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { mode, promptText, targetRoleOrProgram, language } = req.body ?? {};
      if (typeof promptText !== 'string' || !promptText.trim()) {
        res.status(400).json({ error: 'Input details are required.' });
        return;
      }
      const lang = safeLang(language);
      const ai = getAiClient();

      const { result: response, model } = await generateWithRetry((m) =>
        ai.models.generateContent({
          model: m,
          contents: `Career/Admissions mode: ${String(mode || 'resume')}
Target role / university program: ${String(targetRoleOrProgram || 'Not specified').slice(0, 200)}
Language: ${LANGUAGE_LABELS[lang]}
Student background / draft:\n${promptText.slice(0, 10000)}`,
          config: {
            systemInstruction: `You are a university career advisor and international admissions mentor. Respond in ${LANGUAGE_LABELS[lang]}. Provide actionable, honest feedback without fabricating credentials.`,
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          },
        })
      );

      res.json({
        output: response.text || '',
        usageStats: { model, totalTokens: response.usageMetadata?.totalTokenCount || 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });
}
