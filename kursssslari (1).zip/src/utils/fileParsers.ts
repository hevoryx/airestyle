import mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';

export interface ParsedUpload {
  fileName: string;
  mimeType: string;
  kind: 'text' | 'binary';
  extractedText?: string;
  base64Data?: string;
  sizeBytes: number;
}

const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
};

const extractPptxText = async (buffer: ArrayBuffer): Promise<string> => {
  const zip = await JSZip.loadAsync(buffer);
  const slideFiles = Object.keys(zip.files)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/i.test(name))
    .sort((a, b) => {
      const na = parseInt(a.match(/\d+/)?.[0] || '0', 10);
      const nb = parseInt(b.match(/\d+/)?.[0] || '0', 10);
      return na - nb;
    });

  const sections: string[] = [];
  const parser = new DOMParser();

  for (const path of slideFiles) {
    const xmlStr = await zip.files[path].async('string');
    const doc = parser.parseFromString(xmlStr, 'application/xml');
    const nodes = Array.from(doc.getElementsByTagName('a:t'));
    const text = nodes.map((n) => n.textContent || '').join(' ').replace(/\s+/g, ' ').trim();
    if (text) {
      const slideNum = path.match(/\d+/)?.[0] || '?';
      sections.push(`[Slide ${slideNum}] ${text}`);
    }
  }

  return sections.join('\n\n') || 'No readable text found inside PPTX slides.';
};

export async function parseUploadedFile(file: File): Promise<ParsedUpload> {
  const maxBytes = 8 * 1024 * 1024;
  if (file.size > maxBytes) {
    throw new Error(`File "${file.name}" exceeds the 8 MB limit.`);
  }

  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const mime = file.type || '';

  if (ext === 'txt' || ext === 'md' || ext === 'csv' || mime.startsWith('text/')) {
    const text = await file.text();
    return {
      fileName: file.name,
      mimeType: mime || 'text/plain',
      kind: 'text',
      extractedText: text.slice(0, 120000),
      sizeBytes: file.size,
    };
  }

  if (ext === 'docx' || mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    const buffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer: buffer });
    return {
      fileName: file.name,
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      kind: 'text',
      extractedText: (result.value || '').trim().slice(0, 120000),
      sizeBytes: file.size,
    };
  }

  if (ext === 'xlsx' || ext === 'xls' || mime.includes('spreadsheet') || mime.includes('excel')) {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const sheetsText = workbook.SheetNames.map((name) => {
      const sheet = workbook.Sheets[name];
      const csv = XLSX.utils.sheet_to_csv(sheet);
      return `=== Sheet: ${name} ===\n${csv}`;
    }).join('\n\n');
    return {
      fileName: file.name,
      mimeType: mime || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      kind: 'text',
      extractedText: sheetsText.slice(0, 120000),
      sizeBytes: file.size,
    };
  }

  if (ext === 'pptx' || mime === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
    const buffer = await file.arrayBuffer();
    const pptxText = await extractPptxText(buffer);
    return {
      fileName: file.name,
      mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      kind: 'text',
      extractedText: pptxText.slice(0, 120000),
      sizeBytes: file.size,
    };
  }

  if (
    ext === 'pdf' ||
    mime === 'application/pdf' ||
    ['jpg', 'jpeg', 'png', 'webp'].includes(ext) ||
    mime.startsWith('image/')
  ) {
    const buffer = await file.arrayBuffer();
    const resolvedMime =
      ext === 'pdf'
        ? 'application/pdf'
        : mime || (ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg');
    return {
      fileName: file.name,
      mimeType: resolvedMime,
      kind: 'binary',
      base64Data: arrayBufferToBase64(buffer),
      sizeBytes: file.size,
    };
  }

  throw new Error(`Unsupported file format ".${ext}". Supported: PDF, DOCX, XLSX, PPTX, JPG, PNG, TXT.`);
}
