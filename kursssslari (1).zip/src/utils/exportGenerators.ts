import {
  AlignmentType,
  Document,
  Footer,
  HeadingLevel,
  Packer,
  PageNumber,
  Paragraph,
  TextRun,
} from 'docx';
import { jsPDF } from 'jspdf';
import type { GeneratedAcademicDocument, Slide, Theme } from '../../types';
import { resolveTheme } from '../../utils/themes';

const safeFileName = (text: string, fallback = 'academic-document'): string =>
  text
    .replace(/[\\/:*?"<>|]+/g, ' ')
    .replace(/\s+/g, '_')
    .trim()
    .slice(0, 60) || fallback;

export async function downloadAcademicDocx(docData: GeneratedAcademicDocument): Promise<void> {
  const FONT = 'Times New Roman';
  const SIZE = 28; // 14pt
  const LINE = 360; // 1.5 line spacing
  const FIRST_LINE = 709; // 1.25cm

  const makePara = (text: string, bold = false, centered = false) =>
    new Paragraph({
      alignment: centered ? AlignmentType.CENTER : AlignmentType.JUSTIFIED,
      indent: centered ? undefined : { firstLine: FIRST_LINE },
      spacing: { line: LINE, before: 0, after: 80 },
      children: [new TextRun({ text, font: FONT, size: SIZE, bold })],
    });

  const titleChildren: Paragraph[] = [
    makePara(docData.universityMeta.ministry || 'MINISTRY OF HIGHER EDUCATION', true, true),
    ...(docData.universityMeta.university ? [makePara(docData.universityMeta.university, true, true)] : []),
    ...(docData.universityMeta.faculty ? [makePara(docData.universityMeta.faculty, false, true)] : []),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 1600, after: 400 },
      children: [
        new TextRun({
          text: docData.docType.replace(/_/g, ' ').toUpperCase(),
          font: FONT,
          size: 36,
          bold: true,
        }),
      ],
    }),
    makePara(docData.topic, true, true),
    ...(docData.subject ? [makePara(docData.subject, false, true)] : []),
    ...(docData.universityMeta.student ? [makePara(`Student: ${docData.universityMeta.student}`, false, true)] : []),
    ...(docData.universityMeta.supervisor ? [makePara(`Supervisor: ${docData.universityMeta.supervisor}`, false, true)] : []),
    makePara(
      [docData.universityMeta.city, docData.universityMeta.year].filter(Boolean).join(' — ') || '2026',
      true,
      true
    ),
  ];

  const bodyChildren: Paragraph[] = [
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      pageBreakBefore: true,
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: 'INTRODUCTION', font: FONT, size: SIZE, bold: true })],
    }),
    ...docData.introduction.map((p) => makePara(p)),
  ];

  docData.chapters.forEach((chapter, ci) => {
    bodyChildren.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        pageBreakBefore: true,
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: `${ci + 1}. ${chapter.title}`, font: FONT, size: SIZE, bold: true })],
      })
    );
    chapter.sections.forEach((sec, si) => {
      bodyChildren.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: `${ci + 1}.${si + 1}. ${sec.title}`, font: FONT, size: SIZE, bold: true })],
        })
      );
      sec.paragraphs.forEach((p) => bodyChildren.push(makePara(p)));
      if (sec.examples?.trim()) {
        bodyChildren.push(makePara(sec.examples.trim()));
      }
    });
  });

  bodyChildren.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      pageBreakBefore: true,
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: 'CONCLUSION', font: FONT, size: SIZE, bold: true })],
    }),
    ...docData.conclusion.map((p) => makePara(p)),
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      pageBreakBefore: true,
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: 'REFERENCES', font: FONT, size: SIZE, bold: true })],
    }),
    ...docData.references.map((ref, idx) =>
      makePara(`${idx + 1}. ${ref.citation}${ref.url ? ` (${ref.url})` : ''}`)
    )
  );

  const doc = new Document({
    title: docData.topic,
    creator: docData.universityMeta.student || 'AI University Assistant',
    sections: [
      { children: titleChildren },
      {
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 24 })],
              }),
            ],
          }),
        },
        children: bodyChildren,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${safeFileName(docData.topic)}.docx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function downloadAcademicPdf(docData: GeneratedAcademicDocument): void {
  const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
  const marginX = 25;
  const maxWidth = 165;
  let y = 25;

  const ensureSpace = (needed = 12) => {
    if (y + needed > 275) {
      pdf.addPage();
      y = 22;
    }
  };

  const addWrapped = (text: string, fontSize = 11, bold = false, center = false) => {
    pdf.setFont('helvetica', bold ? 'bold' : 'normal');
    pdf.setFontSize(fontSize);
    const lines = pdf.splitTextToSize(text, maxWidth) as string[];
    for (const line of lines) {
      ensureSpace(fontSize * 0.55);
      if (center) {
        pdf.text(line, 105, y, { align: 'center' });
      } else {
        pdf.text(line, marginX, y);
      }
      y += fontSize * 0.48 + 1.5;
    }
    y += 2;
  };

  // Title page
  addWrapped(docData.universityMeta.ministry || 'MINISTRY OF HIGHER EDUCATION', 11, true, true);
  if (docData.universityMeta.university) addWrapped(docData.universityMeta.university, 12, true, true);
  if (docData.universityMeta.faculty) addWrapped(docData.universityMeta.faculty, 11, false, true);
  y += 30;
  addWrapped(docData.docType.replace(/_/g, ' ').toUpperCase(), 18, true, true);
  y += 6;
  addWrapped(docData.topic, 15, true, true);
  if (docData.subject) addWrapped(docData.subject, 12, false, true);
  y += 25;
  if (docData.universityMeta.student) addWrapped(`Student: ${docData.universityMeta.student}`, 11, false, true);
  if (docData.universityMeta.supervisor) addWrapped(`Supervisor: ${docData.universityMeta.supervisor}`, 11, false, true);
  addWrapped([docData.universityMeta.city, docData.universityMeta.year].filter(Boolean).join(' - ') || '2026', 11, true, true);

  pdf.addPage();
  y = 22;
  addWrapped('INTRODUCTION', 14, true);
  docData.introduction.forEach((p) => addWrapped(p, 11));

  docData.chapters.forEach((ch, ci) => {
    pdf.addPage();
    y = 22;
    addWrapped(`${ci + 1}. ${ch.title}`, 14, true);
    ch.sections.forEach((sec, si) => {
      addWrapped(`${ci + 1}.${si + 1}. ${sec.title}`, 12, true);
      sec.paragraphs.forEach((p) => addWrapped(p, 11));
      if (sec.examples?.trim()) addWrapped(sec.examples.trim(), 10.5);
    });
  });

  pdf.addPage();
  y = 22;
  addWrapped('CONCLUSION', 14, true);
  docData.conclusion.forEach((p) => addWrapped(p, 11));

  y += 6;
  addWrapped('REFERENCES', 14, true);
  docData.references.forEach((ref, idx) => {
    addWrapped(`${idx + 1}. ${ref.citation}${ref.url ? ` — ${ref.url}` : ''}`, 10.5);
  });

  pdf.save(`${safeFileName(docData.topic)}.pdf`);
}

export function downloadPresentationPdf(topic: string, slides: Slide[], themeInput?: Theme | null): void {
  const theme = resolveTheme(themeInput);
  const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [297, 167] });

  slides.forEach((slide, idx) => {
    if (idx > 0) pdf.addPage();
    pdf.setFillColor(theme.colors.background);
    pdf.rect(0, 0, 297, 167, 'F');

    pdf.setTextColor(theme.colors.accent);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(10);
    if (slide.sectionTag) {
      pdf.text(slide.sectionTag.toUpperCase(), 18, 16);
    }

    pdf.setTextColor(theme.colors.primary);
    pdf.setFontSize(22);
    const titleLines = pdf.splitTextToSize(slide.title, 250) as string[];
    pdf.text(titleLines, 18, 28);

    let y = 32 + titleLines.length * 9;
    pdf.setTextColor(theme.colors.text);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(13);

    const textWidth = slide.visual?.items?.length ? 150 : 255;
    slide.content.forEach((line) => {
      const wrapped = pdf.splitTextToSize(`• ${line}`, textWidth) as string[];
      if (y + wrapped.length * 7 < 152) {
        pdf.text(wrapped, 18, y);
        y += wrapped.length * 6.5 + 3;
      }
    });

    if (slide.visual?.items?.length) {
      pdf.setDrawColor(theme.colors.accent);
      pdf.roundedRect(178, 34, 102, 114, 4, 4, 'S');
      pdf.setTextColor(theme.colors.secondary);
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(11);
      pdf.text(slide.visual.heading || 'Key Highlights', 184, 44);
      let vy = 54;
      slide.visual.items.slice(0, 5).forEach((item) => {
        pdf.setTextColor(theme.colors.accent);
        pdf.setFontSize(9.5);
        pdf.text(item.label.slice(0, 38), 184, vy);
        pdf.setTextColor(theme.colors.text);
        pdf.setFont('helvetica', 'normal');
        const valLines = pdf.splitTextToSize(item.value, 90) as string[];
        pdf.text(valLines.slice(0, 2), 184, vy + 4.5);
        vy += 18;
      });
    }

    pdf.setTextColor(theme.colors.textLight);
    pdf.setFontSize(9);
    pdf.text(`${idx + 1} / ${slides.length}`, 280, 160, { align: 'right' });
  });

  pdf.save(`${safeFileName(topic, 'presentation')}.pdf`);
}
