import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import {
  BOOTSTRAP_ADMIN_EMAIL,
  checkIsAdminMarker,
  DEFAULT_PLATFORM_CONFIG,
  subscribePlatformConfig,
  syncUserProfile,
} from '../lib/firestoreService';
import type { Language, PlatformConfig, UserProfile } from '../../types';

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  isAdmin: boolean;
  authReady: boolean;
  authError: string | null;
  platformConfig: PlatformConfig;
  language: Language;
  setLanguage: (lang: Language) => void;
  themeMode: 'light' | 'dark';
  toggleThemeMode: () => void;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  getIdToken: () => Promise<string | null>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const LANG_KEY = 'aua_lang_v1';
const THEME_KEY = 'aua_theme_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [platformConfig, setPlatformConfig] = useState<PlatformConfig>(DEFAULT_PLATFORM_CONFIG);

  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = window.localStorage.getItem(LANG_KEY) as Language | null;
      if (saved && ['uz', 'ru', 'en', 'kaa', 'kk'].includes(saved)) return saved;
    } catch {
      // ignore
    }
    return 'uz';
  });

  const [themeMode, setThemeMode] = useState<'light' | 'dark'>(() => {
    try {
      const saved = window.localStorage.getItem(THEME_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // ignore
    }
    return 'light';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (themeMode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      window.localStorage.setItem(THEME_KEY, themeMode);
    } catch {
      // ignore
    }
  }, [themeMode]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    try {
      window.localStorage.setItem(LANG_KEY, lang);
    } catch {
      // ignore
    }
  }, []);

  const toggleThemeMode = useCallback(() => {
    setThemeMode((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  const loadUserProfile = useCallback(
    async (user: User) => {
      try {
        const email = user.email || `${user.uid}@university.local`;
        const synced = await syncUserProfile({
          uid: user.uid,
          email,
          displayName: user.displayName || email.split('@')[0] || 'Student',
          photoUrl: user.photoURL || undefined,
          preferredLanguage: language,
        });
        setProfile(synced);
        const adminMarker =
          email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL ||
          synced.role === 'admin' ||
          (await checkIsAdminMarker(user.uid));
        setIsAdmin(adminMarker);
        setAuthError(null);
      } catch (err) {
        console.error('Failed to synchronize user profile:', err);
        setAuthError(err instanceof Error ? err.message : 'Profile sync error');
      }
    },
    [language]
  );

  useEffect(() => {
    let unsubConfig: (() => void) | null = null;
    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (unsubConfig) {
        unsubConfig();
        unsubConfig = null;
      }

      if (user) {
        await loadUserProfile(user);
        unsubConfig = subscribePlatformConfig(setPlatformConfig);
      } else {
        setProfile(null);
        setIsAdmin(false);
        setPlatformConfig(DEFAULT_PLATFORM_CONFIG);
      }
      setAuthReady(true);
    });

    return () => {
      unsubAuth();
      if (unsubConfig) unsubConfig();
    };
  }, [loadUserProfile]);

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      setAuthError(msg);
      throw err;
    }
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
  }, []);

  const getIdToken = useCallback(async (): Promise<string | null> => {
    if (!auth.currentUser) return null;
    return auth.currentUser.getIdToken();
  }, []);

  const refreshProfile = useCallback(async () => {
    if (auth.currentUser) {
      await loadUserProfile(auth.currentUser);
    }
  }, [loadUserProfile]);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        isAdmin,
        authReady,
        authError,
        platformConfig,
        language,
        setLanguage,
        themeMode,
        toggleThemeMode,
        signInWithGoogle,
        logout,
        getIdToken,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};
