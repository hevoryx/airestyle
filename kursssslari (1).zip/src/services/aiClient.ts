import { auth } from '../lib/firebase';
import { incrementUserAiUsage, recordSystemLog } from '../lib/firestoreService';

export async function callAiApi<T>(
  endpoint: string,
  body: Record<string, unknown>,
  toolName: string
): Promise<T> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Please sign in with Google to use AI features.');
  }

  const token = await user.getIdToken();
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });

  const text = await response.text();
  let parsed: unknown = null;
  try {
    parsed = text ? JSON.parse(text) : null;
  } catch {
    parsed = null;
  }

  if (!response.ok) {
    const errMessage =
      typeof parsed === 'object' && parsed !== null && 'error' in parsed && typeof (parsed as { error: unknown }).error === 'string'
        ? (parsed as { error: string }).error
        : `Request failed (HTTP ${response.status})`;

    void recordSystemLog({
      userId: user.uid,
      userEmail: user.email || undefined,
      tool: toolName,
      model: 'gemini-4-hydrogen',
      status: 'error',
      tokens: 0,
      errorMessage: errMessage,
    });
    throw new Error(errMessage);
  }

  const result = parsed as T & { usageStats?: { model?: string; totalTokens?: number } };
  const model = result?.usageStats?.model || 'gemini-4-hydrogen';
  const tokens = result?.usageStats?.totalTokens || 0;

  // Record usage asynchronously without blocking user response
  void incrementUserAiUsage(user.uid).catch(() => {});
  void recordSystemLog({
    userId: user.uid,
    userEmail: user.email || undefined,
    tool: toolName,
    model,
    status: 'ok',
    tokens,
  });

  return result;
}
