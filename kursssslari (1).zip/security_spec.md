# Security Specification — AI University Assistant

## 1. Data Invariants
1. A user profile `/users/{userId}` can only be read by its owner (`request.auth.uid == userId`) or an admin, preventing PII exposure.
2. Self-registration on `/users/{userId}` cannot assign `role: 'admin'`, `plan: 'pro'`, or arbitrary `aiMonthlyLimit` values (except the bootstrapped admin email `henoci846@gmail.com` with verified email).
3. All workspace documents, version snapshots, tasks, chats, and study progress records belong strictly to `userId == request.auth.uid`.
4. Subcollection `/workspaces/{docId}/versions/{versionId}` verifies ownership of the parent `/workspaces/{docId}` via `get()`.
5. Timestamps (`createdAt`, `updatedAt`) must equal `request.time` on creation, and `createdAt` + `userId` are immutable on updates.
6. Only verified emails (`request.auth.token.email_verified == true`) may perform writes.
7. `/platformConfig/{configId}` writes are strictly restricted to admins.
8. List queries on user-owned collections explicitly enforce `resource.data.userId == request.auth.uid || isAdmin()`.

## 2. Adversarial Test Matrix ("Dirty Dozen" Payloads)
1. Unauthenticated read of `/users/user_1` -> `PERMISSION_DENIED`
2. Authenticated non-owner read of `/users/other_user` -> `PERMISSION_DENIED`
3. Unverified email user creating `/workspaces/doc_1` -> `PERMISSION_DENIED`
4. Privilege escalation: student creating `/users/{uid}` with `role: 'admin'` -> `PERMISSION_DENIED`
5. Quota tampering: student updating own `aiMonthlyLimit` to `999999` -> `PERMISSION_DENIED`
6. Shadow/Ghost field injection: adding `isSuperUser: true` to `/tasks/{id}` -> `PERMISSION_DENIED`
7. Identity spoofing: user A creating `/workspaces/doc_2` with `userId: 'user_B'` -> `PERMISSION_DENIED`
8. Cross-tenant update: user A updating `/tasks/{task_B}` owned by user B -> `PERMISSION_DENIED`
9. Parent-child orphan/hijack: user A creating `/workspaces/{doc_B}/versions/v1` under user B's doc -> `PERMISSION_DENIED`
10. Timestamp forgery: creating `/chats/c1` with backdated `createdAt` instead of `request.time` -> `PERMISSION_DENIED`
11. Resource poisoning: creating document with invalid/oversized ID `bad/id$123` or oversized string -> `PERMISSION_DENIED`
12. Non-admin modifying `/platformConfig/global` -> `PERMISSION_DENIED`
