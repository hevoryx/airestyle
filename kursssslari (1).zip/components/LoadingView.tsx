import React from 'react';
import { Loader2, FileText } from 'lucide-react';
import { AppStatus, Language } from '../types';
import { translations } from '../utils/translations';

interface LoadingViewProps {
  status: AppStatus;
  language: Language;
}

export const LoadingView: React.FC<LoadingViewProps> = ({ language }) => {
  const t = translations[language];

  return (
    <div className="w-full max-w-md mx-auto text-center p-8 bg-white rounded-2xl border border-slate-200 shadow-sm">
      <div className="relative flex items-center justify-center w-16 h-16 mx-auto mb-5 rounded-full bg-indigo-50 border border-indigo-100">
        <Loader2 className="w-7 h-7 text-indigo-600 animate-spin" />
      </div>

      <h2 className="font-display text-xl font-bold text-slate-900 mb-2">
        {t.loadingPlanTitle}
      </h2>

      <p className="text-sm text-slate-600 mb-6 leading-relaxed">
        {t.loadingPlanSub}
      </p>

      <div className="flex items-center justify-center gap-2 text-indigo-700 bg-indigo-50 border border-indigo-100 py-2.5 px-4 rounded-xl text-sm font-medium">
        <FileText className="w-4 h-4 shrink-0" />
        <span>{t.loadingTextPulse}</span>
      </div>
    </div>
  );
};
