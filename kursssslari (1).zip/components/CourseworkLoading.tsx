import React from 'react';
import { Loader2 } from 'lucide-react';
import type { CourseProgress, Language } from '../types';
import { translations } from '../utils/translations';

interface CourseworkLoadingProps {
  language: Language;
  progress: CourseProgress;
  onCancel: () => void;
}

const stepKey: Record<string, string> = {
  outline: 'cwStepOutline',
  sections: 'cwStepSections',
  intro: 'cwStepSections',
  conclusion: 'cwStepSections',
  references: 'cwStepSections',
};

export const CourseworkLoading: React.FC<CourseworkLoadingProps> = ({ language, progress, onCancel }) => {
  const t = translations[language];
  const percent = progress.total > 0 ? Math.min(100, Math.round((progress.done / progress.total) * 100)) : 0;
  const label = t[stepKey[progress.label] ?? 'cwStepSections'];

  return (
    <div className="w-full max-w-md mx-auto text-center p-8 bg-white rounded-2xl border border-slate-200 shadow-sm">
      <div className="relative flex items-center justify-center w-16 h-16 mx-auto mb-5 rounded-full bg-indigo-50 border border-indigo-100">
        <Loader2 className="w-7 h-7 text-indigo-600 animate-spin" />
      </div>

      <h2 className="font-display text-xl font-bold text-slate-900 mb-2">{t.cwLoadingTitle}</h2>
      <p className="text-sm text-slate-600 mb-6 leading-relaxed">{t.cwLoadingSub}</p>

      <div className="mb-2 flex items-center justify-between text-xs font-medium text-slate-600 tabular-nums">
        <span>{label}</span>
        <span>
          {progress.done} / {progress.total}
        </span>
      </div>
      <div
        className="h-2 w-full rounded-full bg-slate-100 overflow-hidden mb-6"
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className="h-full rounded-full bg-indigo-600 transition-all duration-500"
          style={{ width: `${percent}%` }}
        />
      </div>

      <button
        type="button"
        onClick={onCancel}
        className="px-5 py-2 rounded-lg border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
      >
        {t.cwBtnCancel}
      </button>
    </div>
  );
};
