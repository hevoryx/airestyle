<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/87a46f1a-c526-41a1-88b6-b2ef08cbcbec

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Kurs ishi rejimi (Course work mode)

Yuqoridagi **Kurs ishi** tugmasi orqali ochiladi.

- Mavzu, fan, hajm (20–40 bet), boblar soni (2–4) va til (O'zbek / English / Русский) tanlanadi.
- AI avval reja tuzadi, so'ng kirish, har bir bo'lim, xulosa va adabiyotlar ro'yxatini alohida yozadi.
- Natijani saytning o'zida tahrirlash, istalgan bo'limni "Qayta yozish" mumkin.
- **Word (.docx)** formatida yuklab olinadi: A4, Times New Roman 14, 1,5 interval, chap 30 mm / o'ng 15 mm / yuqori va past 20 mm, titul varag'i, mundarija, bet raqamlari.
- O'zbek matnida `oʻ`, `gʻ` va tutuq belgisi (`ʼ`) avtomatik to'g'rilanadi.

Eslatma: Word faylni ochganda "maydonlarni yangilash" so'ralsa "Ha" ni bosing (mundarija shu bilan to'ladi). Adabiyotlar ro'yxatini albatta o'zingiz tekshiring.

Yangi fayllar: `components/Coursework*.tsx`, `services/courseworkService.ts`, `utils/docxGenerator.ts`, `utils/courseworkPrompts.ts`, `utils/courseworkTranslations.ts`. `npm install` yangi `docx` paketini o'rnatadi.
